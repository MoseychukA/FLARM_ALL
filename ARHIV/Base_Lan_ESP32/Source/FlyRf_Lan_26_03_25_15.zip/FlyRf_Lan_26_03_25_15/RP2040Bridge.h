#pragma once
#include <Arduino.h>

struct RP2040BridgeDiag
{
    bool ready;
    uint32_t linesReceived;
    uint32_t packetsAccepted;
    uint32_t packetsRejected;
    uint32_t shortLineCount;
    uint32_t badPrefixCount;
    uint32_t badFieldCount;
    uint32_t lastPacketMs;
    uint32_t lastAddress;
};

void RP2040Bridge_setup();
void RP2040Bridge_loop();
bool RP2040Bridge_processLine(const char* line);
bool RP2040Bridge_getDiag(RP2040BridgeDiag& outDiag);

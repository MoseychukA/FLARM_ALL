#include <Arduino.h>
#include "ESP32RF.h"
#include "Container.h"
#include "FlarmRFM95.h"
#include "FlarmDecoder.h"
#include "RP2040Bridge.h"

static const char* sourceToText(TrafficSource source)
{
    switch (source)
    {
    case TRAFFIC_SOURCE_FLARM_LORA: return "FLARM";
    case TRAFFIC_SOURCE_ADSB_DUMP1090: return "ADSB";
    default: return "UNK";
    }
}

void Display_setup()
{
    Serial.println("[Display] init");
}

void Display_loop()
{
    static uint32_t t = 0;
    if (millis() - t < 3000UL)
    {
        return;
    }

    t = millis();

    Serial.println("---- Container ----");

    FlarmRFM95Diag diag = {};
    const bool diagOk = FlarmRFM95_getDiag(diag);
    Serial.printf("FLARM ready:%s ver:0x%02X packets:%lu crcErr:%lu hdrErr:%lu empty:%lu restart:%lu\r\n",
                  diagOk ? "yes" : "no",
                  diag.version,
                  (unsigned long)diag.packetsReceived,
                  (unsigned long)diag.packetsCrcError,
                  (unsigned long)diag.headerErrorCount,
                  (unsigned long)diag.emptyPacketCount,
                  (unsigned long)diag.restartCount);

    if (diagOk)
    {
        Serial.printf("Freq:%luHz OP:0x%02X MC1:0x%02X MC2:0x%02X MC3:0x%02X LNA:0x%02X lastRSSI:%d lastSNR:%.1f age:%lu ms\r\n",
                      (unsigned long)diag.frequencyHz,
                      diag.opMode,
                      diag.modemConfig1,
                      diag.modemConfig2,
                      diag.modemConfig3,
                      diag.lna,
                      diag.lastRSSI,
                      diag.lastSNR,
                      (unsigned long)diag.lastPacketAgeMs);
    }

    FlarmRawPacket pkt = {};
    if (FlarmRFM95_getLastPacket(pkt))
    {
        Serial.printf("Last RX len:%u RSSI:%d SNR:%.1f age:%lu ms\r\n",
                      (unsigned)pkt.length,
                      pkt.rssi,
                      pkt.snr,
                      (unsigned long)(millis() - pkt.receivedAt));
    }

    FlarmDecodeDiag dec = {};
    FlarmDecoder_getDiag(dec);
    Serial.printf("Decoder ok:%lu cand:%lu reject:%lu short:%lu empty:%lu invalid:%lu clamp:%lu lastICAO:%06lX lastLen:%u\r\n",
                  (unsigned long)dec.okCount,
                  (unsigned long)dec.candidateCount,
                  (unsigned long)dec.rejectCount,
                  (unsigned long)dec.shortPacketCount,
                  (unsigned long)dec.emptyPatternCount,
                  (unsigned long)dec.invalidFieldCount,
                  (unsigned long)dec.positionClampCount,
                  (unsigned long)dec.lastIcao,
                  (unsigned)dec.lastLength);

    if (dec.lastDecodeMs != 0UL)
    {
        Serial.printf("Decoder lastRSSI:%d lastSNR:%.1f age:%lu ms\r\n",
                      dec.lastRssi,
                      dec.lastSnr,
                      (unsigned long)(millis() - dec.lastDecodeMs));
    }


    RP2040BridgeDiag bridge = {};
    if (RP2040Bridge_getDiag(bridge))
    {
        Serial.printf("RP2040Bridge ready:%s lines:%lu ok:%lu reject:%lu short:%lu prefix:%lu fields:%lu lastICAO:%06lX age:%lu ms\r\n",
                      bridge.ready ? "yes" : "no",
                      (unsigned long)bridge.linesReceived,
                      (unsigned long)bridge.packetsAccepted,
                      (unsigned long)bridge.packetsRejected,
                      (unsigned long)bridge.shortLineCount,
                      (unsigned long)bridge.badPrefixCount,
                      (unsigned long)bridge.badFieldCount,
                      (unsigned long)bridge.lastAddress,
                      bridge.lastPacketMs ? (unsigned long)(millis() - bridge.lastPacketMs) : 0UL);
    }

    Serial.printf("Container count:%d\r\n", Container.getCount());
    const Aircraft* list = Container.getList();
    for (int i = 0; i < MAX_AIRCRAFT; i++)
    {
        if (list[i].valid)
        {
            Serial.printf("ICAO:%06lX SRC:%s LAT:%.5f LON:%.5f ALT:%d SPD:%.1f CRS:%.1f RSSI:%d SNR:%.1f age:%lu ms\r\n",
                          (unsigned long)list[i].icao,
                          sourceToText(list[i].source),
                          list[i].lat,
                          list[i].lon,
                          list[i].altitude,
                          list[i].speed,
                          list[i].course,
                          list[i].rssi,
                          list[i].snr,
                          (unsigned long)(millis() - list[i].lastUpdate));
        }
    }
}

#include "RP2040Bridge.h"
#include "Container.h"
#include <string.h>
#include <stdlib.h>

#ifndef RP2040BRIDGE_INPUT_STREAM
#define RP2040BRIDGE_INPUT_STREAM Serial
#endif

#ifndef RP2040BRIDGE_ENABLE_TEST_FRAMES
#define RP2040BRIDGE_ENABLE_TEST_FRAMES 0
#endif

#ifndef RP2040BRIDGE_LINE_BUFFER
#define RP2040BRIDGE_LINE_BUFFER 160
#endif

static RP2040BridgeDiag g_diag = {};
static char g_line[RP2040BRIDGE_LINE_BUFFER];
static size_t g_len = 0;

static bool parseHex24(const char* s, uint32_t& out)
{
    if (s == nullptr || *s == '\0') return false;
    char* end = nullptr;
    unsigned long v = strtoul(s, &end, 16);
    if (end == nullptr || *end != '\0' || v == 0UL || v > 0xFFFFFFUL) return false;
    out = (uint32_t)v;
    return true;
}

static bool parseFloatField(const char* s, float& out)
{
    if (s == nullptr || *s == '\0') return false;
    char* end = nullptr;
    out = strtof(s, &end);
    return end != nullptr && *end == '\0';
}

static bool parseIntField(const char* s, int& out)
{
    if (s == nullptr || *s == '\0') return false;
    char* end = nullptr;
    long v = strtol(s, &end, 10);
    if (end == nullptr || *end != '\0') return false;
    out = (int)v;
    return true;
}

static bool validateCandidate(const TrafficCandidate& c)
{
    if (!c.valid || c.address == 0 || c.address > 0xFFFFFFUL) return false;
    if (c.lat < -90.0f || c.lat > 90.0f) return false;
    if (c.lon < -180.0f || c.lon > 180.0f) return false;
    if (c.altitude < -1000 || c.altitude > 70000) return false;
    if (c.speed < 0.0f || c.speed > 1500.0f) return false;
    if (c.course < 0.0f || c.course >= 360.0f) return false;
    return true;
}

bool RP2040Bridge_processLine(const char* line)
{
    ++g_diag.linesReceived;

    if (line == nullptr || *line == '\0')
    {
        ++g_diag.packetsRejected;
        ++g_diag.shortLineCount;
        return false;
    }

    char buf[RP2040BRIDGE_LINE_BUFFER];
    strncpy(buf, line, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';

    const size_t len = strlen(buf);
    if (len < 16)
    {
        ++g_diag.packetsRejected;
        ++g_diag.shortLineCount;
        return false;
    }

    char* fields[8] = {};
    size_t count = 0;
    char* savePtr = nullptr;
    for (char* tok = strtok_r(buf, ",", &savePtr); tok != nullptr && count < 8; tok = strtok_r(nullptr, ",", &savePtr))
    {
        fields[count++] = tok;
    }

    if (count != 8)
    {
        ++g_diag.packetsRejected;
        ++g_diag.badFieldCount;
        return false;
    }

    if (strcmp(fields[0], "$PFLYRF") != 0 || strcmp(fields[1], "ADSB") != 0)
    {
        ++g_diag.packetsRejected;
        ++g_diag.badPrefixCount;
        return false;
    }

    TrafficCandidate c = {};
    c.source = TRAFFIC_SOURCE_ADSB_DUMP1090;
    c.timestampMs = millis();
    c.rssi = 0;
    c.snr = 0.0f;
    c.valid = true;

    if (!parseHex24(fields[2], c.address) ||
        !parseFloatField(fields[3], c.lat) ||
        !parseFloatField(fields[4], c.lon) ||
        !parseIntField(fields[5], c.altitude) ||
        !parseFloatField(fields[6], c.speed) ||
        !parseFloatField(fields[7], c.course))
    {
        ++g_diag.packetsRejected;
        ++g_diag.badFieldCount;
        return false;
    }

    if (!validateCandidate(c))
    {
        ++g_diag.packetsRejected;
        ++g_diag.badFieldCount;
        return false;
    }

    Container.updateFromCandidate(c);
    ++g_diag.packetsAccepted;
    g_diag.lastPacketMs = c.timestampMs;
    g_diag.lastAddress = c.address;
    return true;
}

void RP2040Bridge_setup()
{
    g_diag = {};
    g_diag.ready = true;
}

void RP2040Bridge_loop()
{
#if RP2040BRIDGE_ENABLE_TEST_FRAMES
    static uint32_t lastTestMs = 0;
    if (millis() - lastTestMs > 5000UL)
    {
        lastTestMs = millis();
        RP2040Bridge_processLine("$PFLYRF,ADSB,4CA123,50.11090,8.68210,1450,122.0,87.0");
    }
#endif

    while (RP2040BRIDGE_INPUT_STREAM.available() > 0)
    {
        const int ch = RP2040BRIDGE_INPUT_STREAM.read();
        if (ch < 0) break;

        if (ch == '\r')
        {
            continue;
        }
        if (ch == '\n')
        {
            g_line[g_len] = '\0';
            if (g_len > 0)
            {
                RP2040Bridge_processLine(g_line);
            }
            g_len = 0;
            continue;
        }

        if (g_len + 1 < sizeof(g_line))
        {
            g_line[g_len++] = (char)ch;
        }
        else
        {
            g_len = 0;
            ++g_diag.packetsRejected;
            ++g_diag.shortLineCount;
        }
    }
}

bool RP2040Bridge_getDiag(RP2040BridgeDiag& outDiag)
{
    outDiag = g_diag;
    return g_diag.ready;
}

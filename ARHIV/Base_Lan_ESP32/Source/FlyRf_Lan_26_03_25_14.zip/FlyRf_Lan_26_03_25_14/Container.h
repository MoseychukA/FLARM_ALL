#pragma once
#include <Arduino.h>
#include "TrafficTypes.h"

#define MAX_AIRCRAFT 50
#ifndef CONTAINER_STALE_TIMEOUT_MS
#define CONTAINER_STALE_TIMEOUT_MS 30000UL
#endif

struct Aircraft
{
    uint32_t icao;
    float lat;
    float lon;
    int altitude;
    float speed;
    float course;
    uint32_t lastUpdate;
    int rssi;
    float snr;
    TrafficSource source;
    bool valid;
};

class ContainerClass
{
public:
    void init();
    void update(const Aircraft& ac);
    void updateFromCandidate(const TrafficCandidate& candidate);
    void removeStale(uint32_t nowMs = millis());
    Aircraft* getList();
    const Aircraft* getList() const;
    int getCount() const;

private:
    Aircraft list[MAX_AIRCRAFT];
};

extern ContainerClass Container;

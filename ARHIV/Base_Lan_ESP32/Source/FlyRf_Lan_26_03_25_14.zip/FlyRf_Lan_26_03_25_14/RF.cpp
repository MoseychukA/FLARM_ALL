#include <Arduino.h>
#include "RF.h"
#include "FlarmRFM95.h"
#include "Log.h"

void RF_setup()
{
    LOGI("RF", "init");
    FlarmRFM95_setup();
}

void RF_loop()
{
    FlarmRFM95_loop();
}

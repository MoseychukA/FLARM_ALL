#include "Container.h"
#include <string.h>

ContainerClass Container;

void ContainerClass::init()
{
    memset(list, 0, sizeof(list));
}

void ContainerClass::update(const Aircraft& ac)
{
    if (ac.icao == 0)
    {
        return;
    }

    for (int i = 0; i < MAX_AIRCRAFT; i++)
    {
        if (list[i].valid && list[i].icao == ac.icao)
        {
            list[i] = ac;
            list[i].valid = true;
            return;
        }
    }

    for (int i = 0; i < MAX_AIRCRAFT; i++)
    {
        if (!list[i].valid)
        {
            list[i] = ac;
            list[i].valid = true;
            return;
        }
    }

    int oldest = 0;
    for (int i = 1; i < MAX_AIRCRAFT; i++)
    {
        if (list[i].lastUpdate < list[oldest].lastUpdate)
        {
            oldest = i;
        }
    }

    list[oldest] = ac;
    list[oldest].valid = true;
}

void ContainerClass::updateFromCandidate(const TrafficCandidate& candidate)
{
    if (!candidate.valid || candidate.address == 0)
    {
        return;
    }

    Aircraft ac = {};
    ac.icao = candidate.address;
    ac.lat = candidate.lat;
    ac.lon = candidate.lon;
    ac.altitude = candidate.altitude;
    ac.speed = candidate.speed;
    ac.course = candidate.course;
    ac.lastUpdate = candidate.timestampMs;
    ac.rssi = candidate.rssi;
    ac.snr = candidate.snr;
    ac.source = candidate.source;
    ac.valid = true;
    update(ac);
}

void ContainerClass::removeStale(uint32_t nowMs)
{
    for (int i = 0; i < MAX_AIRCRAFT; ++i)
    {
        if (!list[i].valid)
        {
            continue;
        }

        if ((uint32_t)(nowMs - list[i].lastUpdate) > CONTAINER_STALE_TIMEOUT_MS)
        {
            memset(&list[i], 0, sizeof(list[i]));
        }
    }
}

Aircraft* ContainerClass::getList()
{
    return list;
}

const Aircraft* ContainerClass::getList() const
{
    return list;
}

int ContainerClass::getCount() const
{
    int count = 0;
    for (int i = 0; i < MAX_AIRCRAFT; i++)
    {
        if (list[i].valid)
        {
            count++;
        }
    }
    return count;
}

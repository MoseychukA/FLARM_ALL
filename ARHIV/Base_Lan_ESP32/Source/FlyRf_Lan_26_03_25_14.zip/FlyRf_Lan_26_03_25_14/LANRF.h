#pragma once
void LAN_setup();
void LAN_loop();
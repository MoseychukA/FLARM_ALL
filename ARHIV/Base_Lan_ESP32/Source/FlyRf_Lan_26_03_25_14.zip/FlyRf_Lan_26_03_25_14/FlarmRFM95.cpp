#include "FlarmRFM95.h"
#include "FlarmDecoder.h"
#include "Log.h"
#include <SPI.h>
#include <string.h>

static const uint8_t REG_FIFO                = 0x00;
static const uint8_t REG_OP_MODE             = 0x01;
static const uint8_t REG_FRF_MSB             = 0x06;
static const uint8_t REG_FRF_MID             = 0x07;
static const uint8_t REG_FRF_LSB             = 0x08;
static const uint8_t REG_LNA                 = 0x0C;
static const uint8_t REG_FIFO_ADDR_PTR       = 0x0D;
static const uint8_t REG_FIFO_TX_BASE_ADDR   = 0x0E;
static const uint8_t REG_FIFO_RX_BASE_ADDR   = 0x0F;
static const uint8_t REG_FIFO_RX_CURRENT     = 0x10;
static const uint8_t REG_IRQ_FLAGS           = 0x12;
static const uint8_t REG_RX_NB_BYTES         = 0x13;
static const uint8_t REG_PKT_SNR_VALUE       = 0x19;
static const uint8_t REG_PKT_RSSI_VALUE      = 0x1A;
static const uint8_t REG_MODEM_CONFIG_1      = 0x1D;
static const uint8_t REG_MODEM_CONFIG_2      = 0x1E;
static const uint8_t REG_PREAMBLE_MSB        = 0x20;
static const uint8_t REG_PREAMBLE_LSB        = 0x21;
static const uint8_t REG_PAYLOAD_LENGTH      = 0x22;
static const uint8_t REG_MODEM_CONFIG_3      = 0x26;
static const uint8_t REG_SYNC_WORD           = 0x39;
static const uint8_t REG_VERSION             = 0x42;

static const uint8_t MODE_LONG_RANGE_MODE    = 0x80;
static const uint8_t MODE_SLEEP              = 0x00;
static const uint8_t MODE_STDBY              = 0x01;
static const uint8_t MODE_RX_CONTINUOUS      = 0x05;

static const uint8_t IRQ_RX_TIMEOUT_MASK     = 0x80;
static const uint8_t IRQ_RX_DONE_MASK        = 0x40;
static const uint8_t IRQ_PAYLOAD_CRC_ERROR   = 0x20;
static const uint8_t IRQ_VALID_HEADER_MASK   = 0x10;
static const uint8_t IRQ_CLEAR_ALL           = 0xFF;

static SPISettings g_spiSettings(FLARM_RFM95_SPI_HZ, MSBFIRST, SPI_MODE0);
static bool g_flarmReady = false;
static uint32_t g_flarmPackets = 0;
static uint32_t g_flarmPacketsCrcError = 0;
static uint32_t g_flarmHeaderErrors = 0;
static uint32_t g_flarmEmptyPackets = 0;
static uint32_t g_lastPollMs = 0;
static uint32_t g_restartCount = 0;
static uint32_t g_receiverStartMs = 0;
static int g_chipVersion = -1;
static bool g_registerDumpDone = false;
static FlarmRawPacket g_lastPacket = {};

static uint8_t rfm95_readReg(uint8_t reg)
{
    SPI.beginTransaction(g_spiSettings);
    digitalWrite(FLARM_RFM95_CS_PIN, LOW);
    SPI.transfer(reg & 0x7F);
    const uint8_t value = SPI.transfer(0x00);
    digitalWrite(FLARM_RFM95_CS_PIN, HIGH);
    SPI.endTransaction();
    return value;
}

static void rfm95_writeReg(uint8_t reg, uint8_t value)
{
    SPI.beginTransaction(g_spiSettings);
    digitalWrite(FLARM_RFM95_CS_PIN, LOW);
    SPI.transfer(reg | 0x80);
    SPI.transfer(value);
    digitalWrite(FLARM_RFM95_CS_PIN, HIGH);
    SPI.endTransaction();
}

static void rfm95_burstRead(uint8_t reg, uint8_t* dst, size_t len)
{
    SPI.beginTransaction(g_spiSettings);
    digitalWrite(FLARM_RFM95_CS_PIN, LOW);
    SPI.transfer(reg & 0x7F);
    for (size_t i = 0; i < len; ++i)
    {
        dst[i] = SPI.transfer(0x00);
    }
    digitalWrite(FLARM_RFM95_CS_PIN, HIGH);
    SPI.endTransaction();
}

static void rfm95_reset()
{
    digitalWrite(FLARM_RFM95_RST_PIN, LOW);
    delay(10);
    digitalWrite(FLARM_RFM95_RST_PIN, HIGH);
    delay(20);
}

static void rfm95_setFrequency(uint32_t hz)
{
    const uint64_t frf = ((uint64_t)hz << 19) / 32000000ULL;
    rfm95_writeReg(REG_FRF_MSB, (uint8_t)(frf >> 16));
    rfm95_writeReg(REG_FRF_MID, (uint8_t)(frf >> 8));
    rfm95_writeReg(REG_FRF_LSB, (uint8_t)(frf));
}

static uint32_t rfm95_readFrequencyHz()
{
    const uint32_t frf = ((uint32_t)rfm95_readReg(REG_FRF_MSB) << 16) |
                         ((uint32_t)rfm95_readReg(REG_FRF_MID) << 8) |
                         ((uint32_t)rfm95_readReg(REG_FRF_LSB));
    return (uint32_t)(((uint64_t)frf * 32000000ULL) >> 19);
}

static bool rfm95_configureRxLoRa()
{
    rfm95_writeReg(REG_OP_MODE, MODE_LONG_RANGE_MODE | MODE_SLEEP);
    delay(5);
    rfm95_writeReg(REG_OP_MODE, MODE_LONG_RANGE_MODE | MODE_STDBY);
    delay(5);

    g_chipVersion = (int)rfm95_readReg(REG_VERSION);
    if (g_chipVersion != 0x12)
    {
        LOGE("FLARM", "RFM95/SX1276 not found, version=0x%02X", g_chipVersion & 0xFF);
        return false;
    }

    rfm95_setFrequency(FLARM_RFM95_FREQ_HZ);
    rfm95_writeReg(REG_FIFO_TX_BASE_ADDR, 0x00);
    rfm95_writeReg(REG_FIFO_RX_BASE_ADDR, 0x00);
    rfm95_writeReg(REG_FIFO_ADDR_PTR, 0x00);
    rfm95_writeReg(REG_LNA, 0x23);
    rfm95_writeReg(REG_MODEM_CONFIG_1, 0x72);
    rfm95_writeReg(REG_MODEM_CONFIG_2, 0x74);
    rfm95_writeReg(REG_MODEM_CONFIG_3, 0x04);
    rfm95_writeReg(REG_PREAMBLE_MSB, 0x00);
    rfm95_writeReg(REG_PREAMBLE_LSB, 0x08);
    rfm95_writeReg(REG_PAYLOAD_LENGTH, FLARM_RFM95_MAX_PACKET);
    rfm95_writeReg(REG_SYNC_WORD, 0x12);
    rfm95_writeReg(REG_IRQ_FLAGS, IRQ_CLEAR_ALL);
    rfm95_writeReg(REG_OP_MODE, MODE_LONG_RANGE_MODE | MODE_RX_CONTINUOUS);
    delay(2);
    return true;
}

static void rfm95_clearIrq(uint8_t mask)
{
    if (mask != 0)
    {
        rfm95_writeReg(REG_IRQ_FLAGS, mask);
    }
}

static bool rfm95_readPacket(FlarmRawPacket& packet)
{
    const uint8_t irqFlags = rfm95_readReg(REG_IRQ_FLAGS);
    if (irqFlags == 0x00)
    {
        return false;
    }

    uint8_t clearMask = 0;
    if (irqFlags & IRQ_RX_TIMEOUT_MASK)
    {
        clearMask |= IRQ_RX_TIMEOUT_MASK;
    }

    if (irqFlags & IRQ_PAYLOAD_CRC_ERROR)
    {
        ++g_flarmPacketsCrcError;
        clearMask |= IRQ_PAYLOAD_CRC_ERROR;
    }

    if ((irqFlags & IRQ_VALID_HEADER_MASK) == 0 && (irqFlags & IRQ_RX_DONE_MASK) == 0)
    {
        ++g_flarmHeaderErrors;
    }
    else if (irqFlags & IRQ_VALID_HEADER_MASK)
    {
        clearMask |= IRQ_VALID_HEADER_MASK;
    }

    if ((irqFlags & IRQ_RX_DONE_MASK) == 0)
    {
        rfm95_clearIrq(clearMask);
        return false;
    }

    if (irqFlags & IRQ_PAYLOAD_CRC_ERROR)
    {
        clearMask |= IRQ_RX_DONE_MASK;
        rfm95_clearIrq(clearMask);
        return false;
    }

    uint8_t length = rfm95_readReg(REG_RX_NB_BYTES);
    if (length == 0)
    {
        ++g_flarmEmptyPackets;
        clearMask |= IRQ_RX_DONE_MASK;
        rfm95_clearIrq(clearMask);
        return false;
    }

    if (length > FLARM_RFM95_MAX_PACKET)
    {
        length = FLARM_RFM95_MAX_PACKET;
    }

    const uint8_t currentAddr = rfm95_readReg(REG_FIFO_RX_CURRENT);
    rfm95_writeReg(REG_FIFO_ADDR_PTR, currentAddr);
    rfm95_burstRead(REG_FIFO, packet.data, length);

    packet.length = length;
    packet.receivedAt = millis();

    const int8_t snrRaw = (int8_t)rfm95_readReg(REG_PKT_SNR_VALUE);
    packet.snr = (float)snrRaw / 4.0f;

    int rssi = (int)rfm95_readReg(REG_PKT_RSSI_VALUE);
    packet.rssi = rssi - 157;
    if (packet.snr < 0.0f)
    {
        packet.rssi += (int)packet.snr;
    }

    packet.valid = true;
    clearMask |= IRQ_RX_DONE_MASK | IRQ_VALID_HEADER_MASK;
    rfm95_clearIrq(clearMask);
    return true;
}

static void logPacketHex(const FlarmRawPacket& packet)
{
    char hexLine[FLARM_RFM95_MAX_PACKET * 3 + 1];
    size_t pos = 0;
    hexLine[0] = '\0';

    for (size_t i = 0; i < packet.length && pos + 4 < sizeof(hexLine); ++i)
    {
        pos += (size_t)snprintf(&hexLine[pos], sizeof(hexLine) - pos, "%02X ", packet.data[i]);
    }

    LOGI("FLARM", "RX len=%u RSSI=%d SNR=%.1f data=%s",
         (unsigned)packet.length,
         packet.rssi,
         packet.snr,
         hexLine);
}

static void injectTestTarget()
{
#if FLARM_RFM95_ENABLE_TEST_TARGET
    static uint32_t s_lastTestInjectMs = 0;
    if (millis() - s_lastTestInjectMs < 2000UL)
    {
        return;
    }

    s_lastTestInjectMs = millis();

    Aircraft ac = {};
    ac.icao = 0xF1A600;
    ac.lat = 50.1109f + (float)((int)(millis() / 1000UL) % 20 - 10) * 0.0002f;
    ac.lon = 8.6821f + (float)((int)(millis() / 1400UL) % 20 - 10) * 0.0002f;
    ac.altitude = 350;
    ac.speed = 18.0f;
    ac.course = (float)((millis() / 100UL) % 360UL);
    ac.lastUpdate = millis();
    ac.valid = true;

    Container.update(ac);
    ++g_flarmPackets;
    LOGD("FLARM", "test target injected, packets=%lu", (unsigned long)g_flarmPackets);
#endif
}

bool FlarmRFM95_setup()
{
    memset(&g_lastPacket, 0, sizeof(g_lastPacket));
    g_flarmReady = false;
    g_registerDumpDone = false;
    g_flarmPackets = 0;
    g_flarmPacketsCrcError = 0;
    g_flarmHeaderErrors = 0;
    g_flarmEmptyPackets = 0;
    g_lastPollMs = 0;
    g_receiverStartMs = millis();

    pinMode(FLARM_RFM95_CS_PIN, OUTPUT);
    digitalWrite(FLARM_RFM95_CS_PIN, HIGH);

    pinMode(FLARM_RFM95_RST_PIN, OUTPUT);
    digitalWrite(FLARM_RFM95_RST_PIN, HIGH);

    SPI.begin(FLARM_RFM95_SCK_PIN, FLARM_RFM95_MISO_PIN, FLARM_RFM95_MOSI_PIN, FLARM_RFM95_CS_PIN);
    rfm95_reset();

    g_flarmReady = rfm95_configureRxLoRa();
    if (!g_flarmReady)
    {
        return false;
    }

    LOGI("FLARM", "RFM95 RX init ok, version=0x%02X freq=%lu Hz SPI=%luHz pins[SCK=%d MISO=%d MOSI=%d CS=%d RST=%d]",
         g_chipVersion & 0xFF,
         (unsigned long)FLARM_RFM95_FREQ_HZ,
         (unsigned long)FLARM_RFM95_SPI_HZ,
         FLARM_RFM95_SCK_PIN,
         FLARM_RFM95_MISO_PIN,
         FLARM_RFM95_MOSI_PIN,
         FLARM_RFM95_CS_PIN,
         FLARM_RFM95_RST_PIN);
    return true;
}

void FlarmRFM95_restartReceiver()
{
    ++g_restartCount;
    LOGW("FLARM", "restart receiver #%lu", (unsigned long)g_restartCount);
    FlarmRFM95_setup();
}

void FlarmRFM95_loop()
{
    if (!g_flarmReady)
    {
        return;
    }

    if (!g_registerDumpDone)
    {
        FlarmRFM95_dumpRegistersToSerial();
        g_registerDumpDone = true;
    }

    const uint32_t now = millis();
    if ((uint32_t)(now - g_lastPollMs) < FLARM_RFM95_RX_POLL_MS)
    {
        injectTestTarget();
        return;
    }
    g_lastPollMs = now;

    if (rfm95_readReg(REG_VERSION) != 0x12)
    {
        LOGE("FLARM", "chip lost on SPI bus, reinit required");
        g_flarmReady = false;
        return;
    }

    FlarmRawPacket packet = {};
    if (rfm95_readPacket(packet))
    {
        ++g_flarmPackets;
        g_lastPacket = packet;
        logPacketHex(packet);
        FlarmDecoder_process(packet.data, packet.length, packet.rssi, packet.snr);
    }
    else
    {
        const uint32_t silenceMs = g_lastPacket.valid ?
                                   (uint32_t)(now - g_lastPacket.receivedAt) :
                                   (uint32_t)(now - g_receiverStartMs);
        if (silenceMs > FLARM_RFM95_NO_PACKET_RESTART_MS)
        {
            LOGW("FLARM", "no packets for %lu ms, rx restart", (unsigned long)silenceMs);
            FlarmRFM95_restartReceiver();
            return;
        }
    }

    injectTestTarget();
}

bool FlarmRFM95_isReady()
{
    return g_flarmReady;
}

uint32_t FlarmRFM95_packetsReceived()
{
    return g_flarmPackets;
}

uint32_t FlarmRFM95_packetsCrcError()
{
    return g_flarmPacketsCrcError;
}

int FlarmRFM95_chipVersion()
{
    return g_chipVersion;
}

bool FlarmRFM95_getLastPacket(FlarmRawPacket& outPacket)
{
    if (!g_lastPacket.valid)
    {
        return false;
    }

    outPacket = g_lastPacket;
    return true;
}

bool FlarmRFM95_getDiag(FlarmRFM95Diag& outDiag)
{
    memset(&outDiag, 0, sizeof(outDiag));
    outDiag.ready = g_flarmReady;
    outDiag.version = (uint8_t)(g_chipVersion < 0 ? 0 : g_chipVersion);
    outDiag.packetsReceived = g_flarmPackets;
    outDiag.packetsCrcError = g_flarmPacketsCrcError;
    outDiag.headerErrorCount = g_flarmHeaderErrors;
    outDiag.emptyPacketCount = g_flarmEmptyPackets;
    outDiag.restartCount = g_restartCount;

    if (!g_flarmReady)
    {
        return false;
    }

    outDiag.opMode = rfm95_readReg(REG_OP_MODE);
    outDiag.modemConfig1 = rfm95_readReg(REG_MODEM_CONFIG_1);
    outDiag.modemConfig2 = rfm95_readReg(REG_MODEM_CONFIG_2);
    outDiag.modemConfig3 = rfm95_readReg(REG_MODEM_CONFIG_3);
    outDiag.lna = rfm95_readReg(REG_LNA);
    outDiag.version = rfm95_readReg(REG_VERSION);
    outDiag.frequencyHz = rfm95_readFrequencyHz();
    outDiag.lastRSSI = g_lastPacket.valid ? g_lastPacket.rssi : 0;
    outDiag.lastSNR = g_lastPacket.valid ? g_lastPacket.snr : 0.0f;
    outDiag.lastPacketAgeMs = g_lastPacket.valid ? (millis() - g_lastPacket.receivedAt) : 0;
    return true;
}

void FlarmRFM95_dumpRegistersToSerial()
{
    if (!g_flarmReady)
    {
        Serial.println("[FLARM] dump skipped: receiver not ready");
        return;
    }

    const uint8_t regs[] = {
        REG_OP_MODE, REG_FRF_MSB, REG_FRF_MID, REG_FRF_LSB,
        REG_LNA, REG_IRQ_FLAGS, REG_RX_NB_BYTES,
        REG_MODEM_CONFIG_1, REG_MODEM_CONFIG_2, REG_MODEM_CONFIG_3,
        REG_PREAMBLE_MSB, REG_PREAMBLE_LSB, REG_PAYLOAD_LENGTH,
        REG_SYNC_WORD, REG_VERSION
    };

    Serial.println("[FLARM] SX1276 register dump:");
    for (size_t i = 0; i < sizeof(regs); ++i)
    {
        const uint8_t reg = regs[i];
        Serial.printf("  reg[0x%02X] = 0x%02X\r\n", reg, rfm95_readReg(reg));
    }
}

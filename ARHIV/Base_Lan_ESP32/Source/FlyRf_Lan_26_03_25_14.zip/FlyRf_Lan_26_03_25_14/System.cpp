#include <Arduino.h>
#include "System.h"
#include "Container.h"
#include "ESP32RF.h"
#include "LANRF.h"
#include "RF.h"
#include "Log.h"

void SystemSetup()
{
    Log_setup();
    LOGI("System", "Init...");

    Container.init();
    Display_setup();
    RF_setup();
    LAN_setup();
}

void SystemLoop()
{
    Container.removeStale();
    RF_loop();
    LAN_loop();
    Display_loop();
}

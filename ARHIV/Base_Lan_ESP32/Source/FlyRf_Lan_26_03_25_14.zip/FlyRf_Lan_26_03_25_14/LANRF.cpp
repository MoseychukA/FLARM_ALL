#include <Arduino.h>
#include "LANRF.h"

void LAN_setup()
{
    Serial.println("[LAN] init");
}

void LAN_loop()
{
    // сеть позже
}
#pragma once

#include <Arduino.h>

/* SPI (LoRa32 pins mapping) */
#ifndef GPIO_PIN_MOSI
#define GPIO_PIN_MOSI       11
#endif
#ifndef GPIO_PIN_MISO
#define GPIO_PIN_MISO       13
#endif
#ifndef GPIO_PIN_SCK
#define GPIO_PIN_SCK        12
#endif
#ifndef GPIO_PIN_SS
#define GPIO_PIN_SS         46
#endif
#ifndef GPIO_PIN_RST
#define GPIO_PIN_RST        7
#endif
#ifndef GPIO_PIN_SDA
#define GPIO_PIN_SDA        8
#endif
#ifndef GPIO_PIN_SCL
#define GPIO_PIN_SCL        9
#endif

#ifndef FLARM_RFM95_SCK_PIN
#define FLARM_RFM95_SCK_PIN   GPIO_PIN_SCK
#endif
#ifndef FLARM_RFM95_MISO_PIN
#define FLARM_RFM95_MISO_PIN  GPIO_PIN_MISO
#endif
#ifndef FLARM_RFM95_MOSI_PIN
#define FLARM_RFM95_MOSI_PIN  GPIO_PIN_MOSI
#endif
#ifndef FLARM_RFM95_CS_PIN
#define FLARM_RFM95_CS_PIN    GPIO_PIN_SS
#endif
#ifndef FLARM_RFM95_RST_PIN
#define FLARM_RFM95_RST_PIN   GPIO_PIN_RST
#endif

#ifndef FLARM_RFM95_FREQ_HZ
#define FLARM_RFM95_FREQ_HZ   868000000UL
#endif
#ifndef FLARM_RFM95_SPI_HZ
#define FLARM_RFM95_SPI_HZ    8000000UL
#endif
#ifndef FLARM_RFM95_ENABLE_TEST_TARGET
#define FLARM_RFM95_ENABLE_TEST_TARGET 0
#endif
#ifndef FLARM_RFM95_MAX_PACKET
#define FLARM_RFM95_MAX_PACKET 64
#endif
#ifndef FLARM_RFM95_RX_POLL_MS
#define FLARM_RFM95_RX_POLL_MS 5UL
#endif
#ifndef FLARM_RFM95_NO_PACKET_RESTART_MS
#define FLARM_RFM95_NO_PACKET_RESTART_MS 15000UL
#endif

struct FlarmRawPacket
{
    uint8_t data[FLARM_RFM95_MAX_PACKET];
    size_t length;
    int rssi;
    float snr;
    uint32_t receivedAt;
    bool valid;
};

struct FlarmRFM95Diag
{
    bool ready;
    uint8_t opMode;
    uint8_t modemConfig1;
    uint8_t modemConfig2;
    uint8_t modemConfig3;
    uint8_t lna;
    uint8_t version;
    uint32_t frequencyHz;
    uint32_t packetsReceived;
    uint32_t packetsCrcError;
    uint32_t headerErrorCount;
    uint32_t emptyPacketCount;
    uint32_t restartCount;
    uint32_t lastPacketAgeMs;
    int lastRSSI;
    float lastSNR;
};

bool FlarmRFM95_setup();
void FlarmRFM95_loop();
void FlarmRFM95_restartReceiver();
bool FlarmRFM95_isReady();
uint32_t FlarmRFM95_packetsReceived();
uint32_t FlarmRFM95_packetsCrcError();
int FlarmRFM95_chipVersion();
bool FlarmRFM95_getLastPacket(FlarmRawPacket& outPacket);
bool FlarmRFM95_getDiag(FlarmRFM95Diag& outDiag);
void FlarmRFM95_dumpRegistersToSerial();

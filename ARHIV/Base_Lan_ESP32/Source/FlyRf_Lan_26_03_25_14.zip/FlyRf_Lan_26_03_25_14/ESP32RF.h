#pragma once
void Display_setup();
void Display_loop();
#include <Arduino.h>
#include "System.h"
#include "Container.h"
#include "ESP32RF.h"
#include "LANRF.h"
#include "RF.h"
#include "Log.h"
#include "RP2040Bridge.h"

void SystemSetup()
{
    Log_setup();
    LOGI("System", "Init...");

    Container.init();
    Display_setup();
    RF_setup();
    RP2040Bridge_setup();
    LAN_setup();
}

void SystemLoop()
{
    Container.removeStale();
    RF_loop();
    RP2040Bridge_loop();
    LAN_loop();
    Display_loop();
}

#include "RP2040Bridge.h"
#include "Container.h"
#include "Log.h"
#include <string.h>
#include <esp_task_wdt.h>

static RP2040BridgeDiag g_diag = {};
static uint8_t g_rxBuffer[RP2040BRIDGE_PACKET_SIZE] = {0};
static size_t g_rxIndex = 0;
static uint16_t g_gainValues[RP2040BRIDGE_GAIN_VALUES_MAX] = {0U};
static uint8_t g_gainCount = 1U;
static TaskHandle_t g_rp2040Task = nullptr;

__attribute__((weak)) bool unpack_ToDUMP1090(const ToDUMP1090_RAW* inRaw, ToDUMP1090* packet)
{
    if (inRaw == nullptr || packet == nullptr)
    {
        return false;
    }

    memset(packet, 0, sizeof(*packet));
    packet->addr = inRaw->addr;
    packet->squawk = inRaw->squawk;
    memcpy(packet->callsign, inRaw->callsign, sizeof(packet->callsign));
    packet->altitude = inRaw->altitude;
    packet->speed = inRaw->speed;
    packet->course = inRaw->course;
    packet->vert_rate = inRaw->vert_rate;
    packet->lat_msg = inRaw->lat_msg;
    packet->lon_msg = inRaw->lon_msg;
    packet->rssi_rp2040 = inRaw->rssi_rp2040;
    return true;
}

static bool validateDecodedPacket(const ToDUMP1090& packet)
{
    if (packet.addr == 0U || packet.addr > 0xFFFFFFUL)
    {
        return false;
    }

    if (packet.lat_msg < -90.0f || packet.lat_msg > 90.0f)
    {
        return false;
    }

    if (packet.lon_msg < -180.0f || packet.lon_msg > 180.0f)
    {
        return false;
    }

    if (packet.altitude < -1000 || packet.altitude > 70000)
    {
        return false;
    }

    if (packet.speed < 0 || packet.speed > 1500)
    {
        return false;
    }

    if (packet.course < 0 || packet.course >= 360)
    {
        return false;
    }

    return true;
}

static void pushDecodedPacketToContainer(const ToDUMP1090& packet)
{
    TrafficCandidate candidate = {};
    candidate.address = packet.addr;
    candidate.lat = packet.lat_msg;
    candidate.lon = packet.lon_msg;
    candidate.altitude = packet.altitude;
    candidate.speed = (float)packet.speed;
    candidate.course = (float)packet.course;
    candidate.timestampMs = millis();
    candidate.rssi = (int)packet.rssi_rp2040;
    candidate.snr = 0.0f;
    candidate.source = TRAFFIC_SOURCE_ADSB_DUMP1090;
    candidate.valid = true;
    Container.updateFromCandidate(candidate);
}

void RP2040Bridge_setGainValues(const uint16_t* data, uint8_t count)
{
    if (data == nullptr || count == 0U)
    {
        return;
    }

    if (count > RP2040BRIDGE_GAIN_VALUES_MAX)
    {
        count = RP2040BRIDGE_GAIN_VALUES_MAX;
    }

    memcpy(g_gainValues, data, (size_t)count * sizeof(uint16_t));
    g_gainCount = count;
}

void RP2040Bridge_sendGainNow()
{
    RP2040BRIDGE_STREAM.write((uint8_t)START_MARK);
    RP2040BRIDGE_STREAM.write((uint8_t)g_gainCount);

    for (uint8_t i = 0; i < g_gainCount; ++i)
    {
        RP2040BRIDGE_STREAM.write(highByte(g_gainValues[i]));
        RP2040BRIDGE_STREAM.write(lowByte(g_gainValues[i]));
    }

    RP2040BRIDGE_STREAM.write(highByte(END_MARK));
    RP2040BRIDGE_STREAM.write(lowByte(END_MARK));
    RP2040BRIDGE_STREAM.flush();
    ++g_diag.gainPacketsSent;
}

void RP2040Bridge_sendGainSingle(uint16_t gain)
{
    RP2040Bridge_setGainValues(&gain, 1U);
    RP2040Bridge_sendGainNow();
}

bool RP2040Bridge_processPacket(const uint8_t* data, size_t len)
{
    ++g_diag.packetsReceived;

    if (data == nullptr || len != sizeof(ToDUMP1090_RAW))
    {
        ++g_diag.packetsRejected;
        return false;
    }

    if (data[len - 3] != 0xFF || data[len - 2] != 0xFF || data[len - 1] != 0xFF)
    {
        ++g_diag.packetsRejected;
        ++g_diag.badTailCount;
        return false;
    }

    ToDUMP1090_RAW inRaw = {};
    ToDUMP1090 packet = {};
    memcpy(&inRaw, data, sizeof(inRaw));

    if (!unpack_ToDUMP1090(&inRaw, &packet))
    {
        ++g_diag.packetsRejected;
        ++g_diag.unpackFailedCount;
        return false;
    }

    if (!validateDecodedPacket(packet))
    {
        ++g_diag.packetsRejected;
        return false;
    }

    pushDecodedPacketToContainer(packet);

    ++g_diag.packetsAccepted;
    g_diag.lastPacketMs = millis();
    g_diag.lastAddress = packet.addr;
    g_diag.lastRssi = (int)packet.rssi_rp2040;
    g_diag.lastPacketSize = (uint8_t)len;
    return true;
}

void receiveRP2040(void* param)
{
    (void)param;
    esp_task_wdt_add(NULL);
    g_diag.taskRunning = true;

    for (;;)
    {
        g_rxIndex = 0;
        esp_task_wdt_reset();

        while (RP2040BRIDGE_STREAM.available())
        {
            const int rd = RP2040BRIDGE_STREAM.read();
            if (rd < 0)
            {
                break;
            }

            const uint8_t b = (uint8_t)rd;
            ++g_diag.bytesReceived;

            if (g_rxIndex < sizeof(g_rxBuffer))
            {
                g_rxBuffer[g_rxIndex++] = b;
            }
            else
            {
                ++g_diag.overflowCount;
                g_rxIndex = 0;
                memset(g_rxBuffer, 0, sizeof(g_rxBuffer));
                continue;
            }

            if (g_rxIndex >= sizeof(ToDUMP1090_RAW))
            {
                RP2040Bridge_processPacket(g_rxBuffer, sizeof(ToDUMP1090_RAW));
                memset(g_rxBuffer, 0, sizeof(g_rxBuffer));
                g_rxIndex = 0;
            }
        }

        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

void RP2040Bridge_setup()
{
    memset(&g_diag, 0, sizeof(g_diag));
    g_rxIndex = 0U;
    RP2040BRIDGE_STREAM.begin(SERIAL_RP2040_SPEED, SERIAL_IN_BITS, SOC_GPIO_PIN_RP2040_RX, SOC_GPIO_PIN_RP2040_TX);
    RP2040BRIDGE_STREAM.setRxBufferSize(RP2040BRIDGE_RX_BUFFER_SIZE);
    g_diag.ready = true;

    const uint16_t defaultGain = 0U;
    RP2040Bridge_setGainValues(&defaultGain, 1U);

    if (g_rp2040Task == nullptr)
    {
        const BaseType_t rc = xTaskCreatePinnedToCore(receiveRP2040, "RP2040", 8192, NULL, 2, &g_rp2040Task, 0);
        if (rc != pdPASS)
        {
            ++g_diag.restartCount;
            LOGI("RP2040", "task create failed");
        }
    }

    LOGI("RP2040", "binary bridge init baud=%lu rx=%d tx=%d packet=%u rxbuf=%u",
         (unsigned long)SERIAL_RP2040_SPEED,
         (int)SOC_GPIO_PIN_RP2040_RX,
         (int)SOC_GPIO_PIN_RP2040_TX,
         (unsigned)sizeof(ToDUMP1090_RAW),
         (unsigned)RP2040BRIDGE_RX_BUFFER_SIZE);
}

void RP2040Bridge_loop()
{
    static uint32_t lastGainMs = 0;
    const uint32_t now = millis();
    if (g_diag.ready && (now - lastGainMs) > 1000UL && g_diag.gainPacketsSent == 0UL)
    {
        lastGainMs = now;
        RP2040Bridge_sendGainNow();
    }
}

bool RP2040Bridge_getDiag(RP2040BridgeDiag& outDiag)
{
    outDiag = g_diag;
    return g_diag.ready;
}

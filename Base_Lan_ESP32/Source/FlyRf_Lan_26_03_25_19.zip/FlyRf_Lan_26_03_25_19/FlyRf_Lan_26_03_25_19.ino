#include <Arduino.h>
#include "System.h"

void setup()
{
    Serial.begin(115200);
    delay(1000);

    Serial.println();
    Serial.println("=== FlyRf Receiver старт (v18) ===");

    SystemSetup();
}

void loop()
{
    SystemLoop();
}

/*
  Модуль Tracker.h
  Назначение:
  - Публичный интерфейс подсистемы внешнего трекера.

  Что содержит файл:
  - Объявления функций запуска, циклического обслуживания и завершения работы трекера.
*/

#pragma once

void Tracker_setup();
void Tracker_loop();
void Tracker_fini();

// Есть ли активное текстовое сообщение трекера для вывода на TFT и RS485.
bool Tracker_hasActiveTextMessage();

// Получить текст активного сообщения с префиксом времени прихода.
const char* Tracker_getActiveTextMessage();

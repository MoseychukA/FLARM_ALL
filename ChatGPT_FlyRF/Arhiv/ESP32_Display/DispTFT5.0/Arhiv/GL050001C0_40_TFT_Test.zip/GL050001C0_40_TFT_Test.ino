/*
  GL050001C0-40 / ESP32-S3 RGB TFT test
  Board: ESP32S3 Dev Module
  Arduino-ESP32: 2.0.11 or compatible 2.x

  Panel configuration taken from the working AMT630A timing measurements:
  800x480, RGB565, PCLK 24 MHz.
*/

#include <Arduino.h>
#include <esp_heap_caps.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_rgb.h>
#include <esp_err.h>

// RGB565 data pins: data_gpio_nums[0..15] = B0..B4, G0..G5, R0..R4.
// These correspond to the panel's B3..B7, G2..G7, R3..R7.
static constexpr int LCD_B3 = 1;
static constexpr int LCD_B4 = 2;
static constexpr int LCD_B5 = 3;
static constexpr int LCD_B6 = 4;
static constexpr int LCD_B7 = 5;
static constexpr int LCD_G2 = 6;
static constexpr int LCD_G3 = 7;
static constexpr int LCD_G4 = 10;
static constexpr int LCD_G5 = 11;
static constexpr int LCD_G6 = 12;
static constexpr int LCD_G7 = 13;
static constexpr int LCD_R3 = 14;
static constexpr int LCD_R4 = 15;
static constexpr int LCD_R5 = 16;
static constexpr int LCD_R6 = 17;
static constexpr int LCD_R7 = 18;

static constexpr int LCD_PCLK  = 48;
static constexpr int LCD_HSYNC = 47;
static constexpr int LCD_VSYNC = 19;  // GPIO46 cannot be used: it is input-only
static constexpr int LCD_DE    = 45;
static constexpr int LCD_BL_EN = 21;
static constexpr int POWER_SENSE = 46;

static constexpr int LCD_WIDTH  = 800;
static constexpr int LCD_HEIGHT = 480;

static esp_lcd_panel_handle_t panel = nullptr;
static uint16_t *frameBuffer = nullptr;

static constexpr uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b) {
  return static_cast<uint16_t>(((r & 0xF8) << 8) |
                               ((g & 0xFC) << 3) |
                               (b >> 3));
}

static void fill(uint16_t color) {
  for (size_t i = 0; i < static_cast<size_t>(LCD_WIDTH) * LCD_HEIGHT; ++i) {
    frameBuffer[i] = color;
  }
}

static void rectangle(int x, int y, int w, int h, uint16_t color) {
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > LCD_WIDTH)  w = LCD_WIDTH - x;
  if (y + h > LCD_HEIGHT) h = LCD_HEIGHT - y;
  if (w <= 0 || h <= 0) return;
  for (int row = y; row < y + h; ++row) {
    uint16_t *dst = frameBuffer + row * LCD_WIDTH + x;
    for (int col = 0; col < w; ++col) dst[col] = color;
  }
}

static void outline(int x, int y, int w, int h, int thickness, uint16_t color) {
  rectangle(x, y, w, thickness, color);
  rectangle(x, y + h - thickness, w, thickness, color);
  rectangle(x, y, thickness, h, color);
  rectangle(x + w - thickness, y, thickness, h, color);
}

static void showFrame() {
  esp_err_t err = esp_lcd_panel_draw_bitmap(panel, 0, 0, LCD_WIDTH, LCD_HEIGHT,
                                             frameBuffer);
  if (err != ESP_OK) {
    Serial.printf("draw_bitmap error: %s\n", esp_err_to_name(err));
  }
}

static void drawColorBars() {
  static const uint16_t colors[] = {
    rgb565(255, 255, 255), rgb565(255, 255, 0), rgb565(0, 255, 255),
    rgb565(0, 255, 0), rgb565(255, 0, 255), rgb565(255, 0, 0),
    rgb565(0, 0, 255), rgb565(0, 0, 0)
  };
  const int barWidth = LCD_WIDTH / 8;
  for (int i = 0; i < 8; ++i) {
    rectangle(i * barWidth, 0, (i == 7) ? LCD_WIDTH - i * barWidth : barWidth,
              LCD_HEIGHT, colors[i]);
  }
  outline(0, 0, LCD_WIDTH, LCD_HEIGHT, 4, rgb565(255, 255, 255));
}

static void drawGrid() {
  fill(rgb565(0, 0, 0));
  const uint16_t gray = rgb565(80, 80, 80);
  for (int x = 0; x < LCD_WIDTH; x += 50) rectangle(x, 0, 1, LCD_HEIGHT, gray);
  for (int y = 0; y < LCD_HEIGHT; y += 40) rectangle(0, y, LCD_WIDTH, 1, gray);
  outline(0, 0, LCD_WIDTH, LCD_HEIGHT, 4, rgb565(255, 255, 255));
  outline(50, 40, LCD_WIDTH - 100, LCD_HEIGHT - 80, 3, rgb565(255, 255, 0));
  outline(100, 80, LCD_WIDTH - 200, LCD_HEIGHT - 160, 3, rgb565(0, 255, 255));
  rectangle(LCD_WIDTH / 2 - 2, 0, 4, LCD_HEIGHT, rgb565(255, 0, 0));
  rectangle(0, LCD_HEIGHT / 2 - 2, LCD_WIDTH, 4, rgb565(255, 0, 0));
}

static void drawGradient() {
  for (int y = 0; y < LCD_HEIGHT; ++y) {
    for (int x = 0; x < LCD_WIDTH; ++x) {
      const uint8_t r = static_cast<uint8_t>((x * 255) / (LCD_WIDTH - 1));
      const uint8_t g = static_cast<uint8_t>((y * 255) / (LCD_HEIGHT - 1));
      const uint8_t b = static_cast<uint8_t>(((x + y) * 255) /
                                             (LCD_WIDTH + LCD_HEIGHT - 2));
      frameBuffer[y * LCD_WIDTH + x] = rgb565(r, g, b);
    }
  }
  outline(0, 0, LCD_WIDTH, LCD_HEIGHT, 4, rgb565(255, 255, 255));
}

static bool initDisplay() {
  pinMode(LCD_BL_EN, OUTPUT);
  digitalWrite(LCD_BL_EN, LOW);
  pinMode(POWER_SENSE, INPUT); // GPIO46 has no usable internal pull-up

  frameBuffer = static_cast<uint16_t *>(heap_caps_malloc(
      LCD_WIDTH * LCD_HEIGHT * sizeof(uint16_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!frameBuffer) {
    Serial.println("ERROR: PSRAM framebuffer allocation failed");
    return false;
  }

  esp_lcd_rgb_panel_config_t config = {};
  config.clk_src = LCD_CLK_SRC_PLL160M;
  config.timings.pclk_hz = 24000000;
  config.timings.h_res = LCD_WIDTH;
  config.timings.v_res = LCD_HEIGHT;
  config.timings.hsync_pulse_width = 64;
  config.timings.hsync_back_porch = 80;
  config.timings.hsync_front_porch = 42;
  config.timings.vsync_pulse_width = 2;
  config.timings.vsync_back_porch = 34;
  config.timings.vsync_front_porch = 38;
  config.timings.flags.pclk_active_neg = false;
  config.data_width = 16;
  config.psram_trans_align = 64;
  config.hsync_gpio_num = LCD_HSYNC;
  config.vsync_gpio_num = LCD_VSYNC;
  config.de_gpio_num = LCD_DE;
  config.pclk_gpio_num = LCD_PCLK;
  config.disp_gpio_num = -1; // panel DISP is pulled up to 3.3 V through 10k
  config.data_gpio_nums[0]  = LCD_B3;
  config.data_gpio_nums[1]  = LCD_B4;
  config.data_gpio_nums[2]  = LCD_B5;
  config.data_gpio_nums[3]  = LCD_B6;
  config.data_gpio_nums[4]  = LCD_B7;
  config.data_gpio_nums[5]  = LCD_G2;
  config.data_gpio_nums[6]  = LCD_G3;
  config.data_gpio_nums[7]  = LCD_G4;
  config.data_gpio_nums[8]  = LCD_G5;
  config.data_gpio_nums[9]  = LCD_G6;
  config.data_gpio_nums[10] = LCD_G7;
  config.data_gpio_nums[11] = LCD_R3;
  config.data_gpio_nums[12] = LCD_R4;
  config.data_gpio_nums[13] = LCD_R5;
  config.data_gpio_nums[14] = LCD_R6;
  config.data_gpio_nums[15] = LCD_R7;
  config.flags.fb_in_psram = true;

  esp_err_t err = esp_lcd_new_rgb_panel(&config, &panel);
  if (err != ESP_OK) {
    Serial.printf("esp_lcd_new_rgb_panel failed: %s\n", esp_err_to_name(err));
    return false;
  }
  if ((err = esp_lcd_panel_reset(panel)) != ESP_OK ||
      (err = esp_lcd_panel_init(panel)) != ESP_OK) {
    Serial.printf("LCD init failed: %s\n", esp_err_to_name(err));
    return false;
  }

  fill(rgb565(0, 0, 0));
  showFrame();
  digitalWrite(LCD_BL_EN, HIGH);
  return true;
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("GL050001C0-40 TFT test");
  Serial.printf("PSRAM size: %u bytes\n", ESP.getPsramSize());
  Serial.printf("Power sense GPIO46: %s\n", digitalRead(POWER_SENSE) ? "HIGH" : "LOW");

  if (!initDisplay()) {
    Serial.println("Display initialization stopped");
    while (true) delay(1000);
  }
  Serial.println("Display initialized");
}

void loop() {
  Serial.println("Test 1: color bars");
  drawColorBars();
  showFrame();
  delay(5000);

  Serial.println("Test 2: geometry/grid");
  drawGrid();
  showFrame();
  delay(5000);

  Serial.println("Test 3: RGB gradient");
  drawGradient();
  showFrame();
  delay(5000);

  static const uint16_t solidColors[] = {
    rgb565(255, 0, 0), rgb565(0, 255, 0), rgb565(0, 0, 255),
    rgb565(255, 255, 255), rgb565(0, 0, 0)
  };
  for (uint16_t color : solidColors) {
    fill(color);
    showFrame();
    delay(1500);
  }
}

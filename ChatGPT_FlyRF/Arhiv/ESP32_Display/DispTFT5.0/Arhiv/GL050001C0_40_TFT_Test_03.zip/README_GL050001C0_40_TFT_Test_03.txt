GL050001C0-40 TFT + Wi-Fi TEST 03 FOR ESP32-S3
==============================================

Arduino IDE settings:

Board:                 ESP32S3 Dev Module
Arduino-ESP32:         3.x (required; do not compile with 2.0.11)
USB CDC On Boot:       Disabled
Flash Size:            16MB
PSRAM:                 OPI PSRAM
Partition Scheme:      any suitable 16MB scheme
Upload Mode:           UART0 / external USB-UART

Important:

1. GPIO19 is used as LCD VSYNC. Native USB uses GPIO19/20 and therefore
   must not be used while the display is connected.
2. GPIO46 is input-only and is used for POWER_SENSE.
3. Panel DISP (pin 31) is connected to 3.3V through a 10k resistor.
4. Backlight must be powered through the AP3032 driver. GPIO21 controls
   only the AP3032 CTRL/EN input.
5. The framebuffer needs working 8MB OPI PSRAM.
6. The sketch cycles through color bars, a geometry grid, an RGB gradient,
   and red/green/blue/white/black full-screen tests.

Wi-Fi WEB test:

Mode:                  Access Point
SSID:                  Test in Russian (Тест) + 6 hexadecimal module digits
Password:              12345678
WEB address:           http://192.168.1.1/

The WEB page shows Wi-Fi status, connected client count, free RAM/PSRAM,
and buttons for selecting the TFT test image. The unique module suffix is
formed from the lower 24 bits of the ESP32-S3 eFuse MAC address.

LCD timing:

Resolution:            800x480
PCLK:                  24 MHz
HSYNC pulse/back/front: 64 / 80 / 42
VSYNC pulse/back/front: 2 / 34 / 38

If the image is shifted, unstable, or colors are wrong, first re-check the
FPC pin numbering and RGB bit order. Do not connect VLED pins directly to
ESP32-S3 or 3.3V.

Version 02 changes:

- Fixed continuous full-frame gradient updates that overloaded RGB DMA.
- Reduced RGB PCLK from 24 MHz to 16 MHz for stable operation with Wi-Fi.
- Added a WEB-selectable smooth-font screen in five different sizes.
- Font edges use bilinear coverage and RGB565 alpha blending.

Version 03 synchronization fix:

- Video analysis confirmed RGB DMA underflow, not wrong HSYNC/VSYNC polarity.
- Enabled a 20-line RGB bounce buffer in internal SRAM.
- The full framebuffer remains in 8MB OPI PSRAM.
- Restored the 24 MHz PCLK measured on the original AMT630A board.
- Arduino-ESP32 3.x is mandatory because 2.0.11 has no RGB bounce-buffer
  configuration field.

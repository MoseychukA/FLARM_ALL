/*
  RS485 внешнего дисплея.

  Приём и обработка пакета повторяют рабочий FlyRf_Disp_26_05_18_01:
  UART разбирается в основном цикле, проверенный wire-пакет сразу переносится
  в ThisAircraft, Container и AuxData без промежуточной очереди.
*/

#include "RS485Display.h"
#include "DeviceInfo.h"
#include "HardwareConfig.h"
#include "DisplayRemote.h"
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <string.h>

// Формат на проводе у приложенной базы, собранной на ESP32 Arduino 2.x.
// Нельзя использовать native time_t дисплея: в Arduino 3.x он может быть
// 64-битным, тогда один и тот же исходный struct становится на 52 байта больше.
typedef struct __attribute__((packed))
{
    uint32_t addr;
    int32_t squawk;
    uint8_t callsign[8];
    float altitude;
    float pressure_altitude;
    float course;
    float speed;
    float distance;
    float bearing;
    int32_t vert_rate;
    float latitude;
    float longitude;
    // На проводе базы это всегда ровно 32 бита. Поле намеренно не time_t:
    // размер time_t зависит от версии ESP32 Arduino core.
    uint32_t timestamp32;
    int8_t rssi_LoRa;
    int8_t rssi_rp2040;
    uint8_t signal_source;
} base_ufo_wire_t;

typedef struct __attribute__((packed))
{
    base_ufo_wire_t ThisAircraft;
    base_ufo_wire_t Container[MAX_TRACKING_OBJECTS];
    aux_t AuxData;
    uint8_t BUTTON1;
    uint8_t BUTTON2;
} base_packet_wire_t;

// Та же запись после сборки базы на toolchain с 64-битным time_t.
typedef struct __attribute__((packed))
{
    uint32_t addr;
    int32_t squawk;
    uint8_t callsign[8];
    float altitude;
    float pressure_altitude;
    float course;
    float speed;
    float distance;
    float bearing;
    int32_t vert_rate;
    float latitude;
    float longitude;
    uint64_t timestamp64;
    int8_t rssi_LoRa;
    int8_t rssi_rp2040;
    uint8_t signal_source;
} base_ufo_wire64_t;

typedef struct __attribute__((packed))
{
    base_ufo_wire64_t ThisAircraft;
    base_ufo_wire64_t Container[MAX_TRACKING_OBJECTS];
    aux_t AuxData;
    uint8_t BUTTON1;
    uint8_t BUTTON2;
} base_packet_wire64_t;

static_assert(sizeof(base_ufo_wire_t) == 59U, "base aircraft wire size changed");
static_assert(sizeof(aux_t) == 454U, "base aux wire size changed");
static_assert(sizeof(base_packet_wire_t) == 1223U, "base payload must be 1223 bytes");
static_assert(sizeof(base_ufo_wire64_t) == 63U, "64-bit aircraft wire size changed");
static_assert(sizeof(base_packet_wire64_t) == 1275U, "64-bit payload must be 1275 bytes");

enum WireTimeFormat : uint8_t
{
    WIRE_TIME_UNKNOWN = 0,
    WIRE_TIME_32 = 4,
    WIRE_TIME_64 = 8
};

static full_packet_net_t g_lastPacket = {};
static aux_t g_inAux = {};
static aux_t g_outAux = {};
static volatile uint8_t g_inButton = 0;
static volatile uint8_t g_localButton = 0;
static uint32_t g_lastRx = 0;
static uint32_t g_rxPackets = 0;
static uint32_t g_txPackets = 0;
static uint32_t g_rxBytes = 0;
static uint32_t g_footerErrors = 0;
static uint32_t g_crcErrors = 0;
static uint32_t g_footerMatches = 0;
static size_t g_lastCandidatePayload = 0U;
static uint32_t g_lastDiagnosticMs = 0;
static WireTimeFormat g_lastWireFormat = WIRE_TIME_UNKNOWN;
static size_t g_lastPayloadSize = 0U;
static size_t g_lastFrameSize = 0U;

static uint8_t g_rxBuffer[sizeof(base_packet_wire64_t) + 64U] = {};
static size_t g_rxBuffered = 0;

static uint16_t crc16_ccitt(const uint8_t* data, size_t length)
{
    uint16_t crc = 0x0000;
    for (size_t index = 0; index < length; ++index)
    {
        crc ^= (uint16_t)data[index] << 8;
        for (uint8_t bit = 0; bit < 8; ++bit)
            crc = (crc & 0x8000U) ?
                  (uint16_t)((crc << 1) ^ 0x1021U) : (uint16_t)(crc << 1);
    }
    return crc;
}

static void rs485SetTX(bool enabled)
{
    digitalWrite(RS485_DE_PIN, enabled ? HIGH : LOW);
    if (enabled) delayMicroseconds(50);
}

static void netToLocalThis(const ufo_net_t& source)
{
    ThisAircraft.addr = source.addr;
    ThisAircraft.squawk = source.squawk;
    memcpy(ThisAircraft.callsign, source.callsign, sizeof(ThisAircraft.callsign));
    ThisAircraft.altitude = source.altitude;
    ThisAircraft.pressure_altitude = source.pressure_altitude;
    ThisAircraft.course = source.course;
    ThisAircraft.speed = source.speed;
    ThisAircraft.vert_rate = source.vert_rate;
    ThisAircraft.latitude = source.latitude;
    ThisAircraft.longitude = source.longitude;
    ThisAircraft.local_latitude = source.latitude;
    ThisAircraft.local_longitude = source.longitude;
    ThisAircraft.timestamp = source.timestamp;
}

static void netToLocalContainer(const ufo_net_t& source, ufo_t& target)
{
    target.addr = source.addr;
    target.squawk = source.squawk;
    memcpy(target.callsign, source.callsign, sizeof(target.callsign));
    target.altitude = source.altitude;
    target.pressure_altitude = source.pressure_altitude;
    target.course = source.course;
    target.speed = source.speed;
    target.distance = source.distance;
    target.bearing = source.bearing;
    target.vert_rate = source.vert_rate;
    target.latitude = source.latitude;
    target.longitude = source.longitude;
    target.timestamp = source.timestamp;
    target.lastUpdate = millis();
    target.rssi_LoRa = source.rssi_LoRa;
    target.rssi_rp2040 = source.rssi_rp2040;
    target.signal_source = source.signal_source;
    target.valid = source.addr != 0U;
}

static void wireAircraftToNative(const base_ufo_wire_t& source, ufo_net_t& target)
{
    memset(&target, 0, sizeof(target));
    target.addr = source.addr;
    target.squawk = source.squawk;
    memcpy(target.callsign, source.callsign, sizeof(target.callsign));
    target.altitude = source.altitude;
    target.pressure_altitude = source.pressure_altitude;
    target.course = source.course;
    target.speed = source.speed;
    target.distance = source.distance;
    target.bearing = source.bearing;
    target.vert_rate = source.vert_rate;
    target.latitude = source.latitude;
    target.longitude = source.longitude;
    // Расширение выполняется только здесь, уже после проверки CRC всего кадра.
    // Сначала сохраняем беззнаковое 32-битное значение базы, затем переводим
    // его в нативный time_t дисплея (на новом core он 64-битный).
    const uint64_t timestamp64 = (uint64_t)source.timestamp32;
    target.timestamp = (time_t)timestamp64;
    target.rssi_LoRa = source.rssi_LoRa;
    target.rssi_rp2040 = source.rssi_rp2040;
    target.signal_source = source.signal_source;
}

static void wireAircraft64ToNative(const base_ufo_wire64_t& source,
                                   ufo_net_t& target)
{
    memset(&target, 0, sizeof(target));
    target.addr = source.addr;
    target.squawk = source.squawk;
    memcpy(target.callsign, source.callsign, sizeof(target.callsign));
    target.altitude = source.altitude;
    target.pressure_altitude = source.pressure_altitude;
    target.course = source.course;
    target.speed = source.speed;
    target.distance = source.distance;
    target.bearing = source.bearing;
    target.vert_rate = source.vert_rate;
    target.latitude = source.latitude;
    target.longitude = source.longitude;
    target.timestamp = (time_t)source.timestamp64;
    target.rssi_LoRa = source.rssi_LoRa;
    target.rssi_rp2040 = source.rssi_rp2040;
    target.signal_source = source.signal_source;
}

static void wirePacketToNative(const base_packet_wire_t& source,
                               full_packet_net_t& target)
{
    memset(&target, 0, sizeof(target));
    wireAircraftToNative(source.ThisAircraft, target.ThisAircraft);
    for (int index = 0; index < MAX_TRACKING_OBJECTS; ++index)
        wireAircraftToNative(source.Container[index], target.Container[index]);
    target.AuxData = source.AuxData;
    target.BUTTON1 = source.BUTTON1;
    target.BUTTON2 = source.BUTTON2;
}

static void wirePacket64ToNative(const base_packet_wire64_t& source,
                                 full_packet_net_t& target)
{
    memset(&target, 0, sizeof(target));
    wireAircraft64ToNative(source.ThisAircraft, target.ThisAircraft);
    for (int index = 0; index < MAX_TRACKING_OBJECTS; ++index)
        wireAircraft64ToNative(source.Container[index], target.Container[index]);
    target.AuxData = source.AuxData;
    target.BUTTON1 = source.BUTTON1;
    target.BUTTON2 = source.BUTTON2;
}

static bool decodeWirePayload(const uint8_t* payload, size_t payloadSize,
                              full_packet_net_t& target,
                              WireTimeFormat& timeFormat)
{
    if (payloadSize == sizeof(base_packet_wire_t))
    {
        base_packet_wire_t source = {};
        memcpy(&source, payload, sizeof(source));
        wirePacketToNative(source, target);
        timeFormat = WIRE_TIME_32;
        return true;
    }
    if (payloadSize == sizeof(base_packet_wire64_t))
    {
        base_packet_wire64_t source = {};
        memcpy(&source, payload, sizeof(source));
        wirePacket64ToNative(source, target);
        timeFormat = WIRE_TIME_64;
        return true;
    }

    // Небольшое отличие AuxData не должно мешать расшифровке самолётов.
    // Размер записи самолёта выбирается по общей длине, после чего все её
    // поля переводятся отдельно; AuxData копируется доступной длиной.
    const bool likelyTime32 = payloadSize < 1250U;
    const size_t aircraftSize = likelyTime32 ?
                                sizeof(base_ufo_wire_t) :
                                sizeof(base_ufo_wire64_t);
    const size_t aircraftBlock = aircraftSize * (MAX_TRACKING_OBJECTS + 1U);
    if (payloadSize < aircraftBlock + 2U) return false;
    const size_t auxBytes = payloadSize - aircraftBlock - 2U;
    if (auxBytes < 400U || auxBytes > 500U) return false;

    memset(&target, 0, sizeof(target));
    if (likelyTime32)
    {
        base_ufo_wire_t aircraft = {};
        memcpy(&aircraft, payload, sizeof(aircraft));
        wireAircraftToNative(aircraft, target.ThisAircraft);
        for (int index = 0; index < MAX_TRACKING_OBJECTS; ++index)
        {
            memcpy(&aircraft, payload + aircraftSize * (size_t)(index + 1),
                   sizeof(aircraft));
            wireAircraftToNative(aircraft, target.Container[index]);
        }
        timeFormat = WIRE_TIME_32;
    }
    else
    {
        base_ufo_wire64_t aircraft = {};
        memcpy(&aircraft, payload, sizeof(aircraft));
        wireAircraft64ToNative(aircraft, target.ThisAircraft);
        for (int index = 0; index < MAX_TRACKING_OBJECTS; ++index)
        {
            memcpy(&aircraft, payload + aircraftSize * (size_t)(index + 1),
                   sizeof(aircraft));
            wireAircraft64ToNative(aircraft, target.Container[index]);
        }
        timeFormat = WIRE_TIME_64;
    }
    const size_t copyBytes = auxBytes < sizeof(target.AuxData) ?
                             auxBytes : sizeof(target.AuxData);
    memcpy(&target.AuxData, payload + aircraftBlock, copyBytes);
    target.BUTTON1 = payload[payloadSize - 2U];
    target.BUTTON2 = payload[payloadSize - 1U];
    return true;
}

void net_to_ufo_Container(const ufo_t* source, ufo_net_t* target)
{
    if (!source || !target) return;
    memset(target, 0, sizeof(*target));
    target->addr = source->addr;
    target->squawk = source->squawk;
    memcpy(target->callsign, source->callsign, sizeof(target->callsign));
    target->altitude = source->altitude;
    target->pressure_altitude = source->pressure_altitude;
    target->course = source->course;
    target->speed = source->speed;
    target->distance = source->distance;
    target->bearing = source->bearing;
    target->vert_rate = source->vert_rate;
    target->latitude = source->latitude;
    target->longitude = source->longitude;
    target->timestamp = source->timestamp;
    target->rssi_LoRa = source->rssi_LoRa;
    target->rssi_rp2040 = source->rssi_rp2040;
    target->signal_source = source->signal_source;
}

void net_to_ufo_ThisAircraft(const ufo_t* source, ufo_net_t* target)
{
    net_to_ufo_Container(source, target);
}

bool receivePacket_RS485(full_packet_net_t* packet, uint8_t* button1, uint8_t* button2)
{
    if (!packet) return false;
    while (RS485_SERIAL.available() && g_rxBuffered < sizeof(g_rxBuffer))
    {
        const int value = RS485_SERIAL.read();
        if (value < 0) break;
        g_rxBuffer[g_rxBuffered++] = (uint8_t)value;
        ++g_rxBytes;
    }
    if (g_rxBuffered < 4U) return false;

    size_t start = 0;
    while (g_rxBuffered - start >= 4U)
    {
        if (g_rxBuffer[start] == 0xDD && g_rxBuffer[start + 1U] == 0xCC &&
            g_rxBuffer[start + 2U] == 0xBB && g_rxBuffer[start + 3U] == 0xAA)
            break;
        ++start;
    }
    if (start > 0U)
    {
        memmove(g_rxBuffer, g_rxBuffer + start, g_rxBuffered - start);
        g_rxBuffered -= start;
    }

    // Ищем реальный footer. Его позиция даёт фактический размер payload;
    // случайная последовательность внутри данных отбрасывается проверкой CRC.
    size_t payloadSize = 0U;
    size_t frameLength = 0U;
    bool validFrameFound = false;
    const size_t firstFooterOffset = 4U + 1100U + 2U;
    for (size_t footerOffset = firstFooterOffset;
         footerOffset + 4U <= g_rxBuffered;
         ++footerOffset)
    {
        if (g_rxBuffer[footerOffset] != 0xAA ||
            g_rxBuffer[footerOffset + 1U] != 0xBB ||
            g_rxBuffer[footerOffset + 2U] != 0xCC ||
            g_rxBuffer[footerOffset + 3U] != 0xDD) continue;

        const size_t candidatePayload = footerOffset - 6U;
        ++g_footerMatches;
        g_lastCandidatePayload = candidatePayload;
        const size_t crcOffset = footerOffset - 2U;
        uint16_t receivedCrc = 0U;
        memcpy(&receivedCrc, &g_rxBuffer[crcOffset], sizeof(receivedCrc));
        const uint16_t calculatedCrc = crc16_ccitt(&g_rxBuffer[4], candidatePayload);
        if (receivedCrc != calculatedCrc)
        {
            ++g_crcErrors;
            continue;
        }
        payloadSize = candidatePayload;
        frameLength = footerOffset + 4U;
        validFrameFound = true;
        break;
    }

    if (!validFrameFound)
    {
        // Максимальный штатный кадр уже помещается в этот буфер. При полном
        // буфере текущий заголовок повреждён: удаляем только его первый байт,
        // чтобы следующий вызов нашёл очередной DD CC BB AA.
        if (g_rxBuffered + 4U >= sizeof(g_rxBuffer))
        {
            --g_rxBuffered;
            memmove(g_rxBuffer, g_rxBuffer + 1U, g_rxBuffered);
            ++g_footerErrors;
        }
        return false;
    }

    WireTimeFormat decodedFormat = WIRE_TIME_UNKNOWN;
    if (!decodeWirePayload(&g_rxBuffer[4], payloadSize, *packet, decodedFormat))
    {
        Serial.print(F("[RS485] CRC OK, unsupported payload/frame="));
        Serial.print(payloadSize); Serial.print('/'); Serial.println(frameLength);
        g_rxBuffered -= frameLength;
        if (g_rxBuffered > 0U)
            memmove(g_rxBuffer, g_rxBuffer + frameLength, g_rxBuffered);
        ++g_footerErrors;
        return false;
    }
    g_lastWireFormat = decodedFormat;
    g_lastPayloadSize = payloadSize;
    g_lastFrameSize = frameLength;
    if (button1) *button1 = packet->BUTTON1;
    if (button2) *button2 = packet->BUTTON2;
    g_rxBuffered -= frameLength;
    if (g_rxBuffered > 0U)
        memmove(g_rxBuffer, g_rxBuffer + frameLength, g_rxBuffered);
    return true;
}

static void sendReply()
{
    static uint8_t reply[sizeof(base_packet_wire64_t)] = {};
    if (g_lastWireFormat == WIRE_TIME_UNKNOWN ||
        g_lastPayloadSize < 4U || g_lastPayloadSize > sizeof(reply)) return;
    memset(reply, 0, g_lastPayloadSize);
    aux_t outgoing = g_outAux;
    outgoing.new_button_M = g_localButton;
    g_localButton = 0;

    const size_t aircraftSize = g_lastWireFormat == WIRE_TIME_64 ?
                                sizeof(base_ufo_wire64_t) :
                                sizeof(base_ufo_wire_t);
    const size_t auxOffset = aircraftSize * (MAX_TRACKING_OBJECTS + 1U);
    const size_t buttonsOffset = g_lastPayloadSize - 2U;
    if (auxOffset >= buttonsOffset) return;
    const size_t availableAux = buttonsOffset - auxOffset;
    const size_t copyBytes = availableAux < sizeof(outgoing) ?
                             availableAux : sizeof(outgoing);
    memcpy(reply + auxOffset, &outgoing, copyBytes);
    const uint16_t crc = crc16_ccitt(reply, g_lastPayloadSize);
    rs485SetTX(true);
    RS485_SERIAL.write((const uint8_t*)&PACKET_HEADER, sizeof(PACKET_HEADER));
    RS485_SERIAL.write(reply, g_lastPayloadSize);
    RS485_SERIAL.write((const uint8_t*)&crc, sizeof(crc));
    RS485_SERIAL.write((const uint8_t*)&PACKET_FOOTER, sizeof(PACKET_FOOTER));
    RS485_SERIAL.flush();
    ++g_txPackets;
    delayMicroseconds(200);
    rs485SetTX(false);
}

static void applyPacket(const full_packet_net_t& packet)
{
    g_lastPacket = packet;
    g_inAux = packet.AuxData;
    netToLocalThis(packet.ThisAircraft);
    for (int index = 0; index < MAX_TRACKING_OBJECTS; ++index)
        netToLocalContainer(packet.Container[index], Container[index]);
    if (packet.AuxData.new_button_M != 0U)
        g_inButton = packet.AuxData.new_button_M;
    g_lastRx = millis();
    ++g_rxPackets;

    Remote_setGnssState(packet.AuxData.isValidGNSS_M,
                        packet.AuxData.gps_time_valid_M,
                        packet.AuxData.gps_satellites_valid_M,
                        packet.AuxData.Time_Hour_M,
                        packet.AuxData.Time_Minute_M,
                        ThisAircraft.latitude, ThisAircraft.longitude,
                        ThisAircraft.altitude, ThisAircraft.hdop);
    Remote_setBaseStatus(packet.AuxData.base_test_mode_M,
                         packet.AuxData.gps_rx_M,
                         packet.AuxData.gps_satellites_M,
                         packet.AuxData.display_coord_valid_M,
                         packet.AuxData.display_coord_is_local_M,
                         packet.AuxData.display_latitude_M,
                         packet.AuxData.display_longitude_M,
                         packet.AuxData.lora_tx_packets_M,
                         packet.AuxData.lora_rx_packets_M,
                         packet.AuxData.lora_rf_hz_M);
    Remote_setLanStatus(packet.AuxData.lan_state_view_M,
                        packet.AuxData.lan_ready_M,
                        packet.AuxData.lan_link_up_M,
                        packet.AuxData.lan_udp_working_M,
                        packet.AuxData.lan_dhcp_M,
                        packet.AuxData.lan_ip_M,
                        packet.AuxData.lan_udp_port_M,
                        packet.AuxData.lan_tx_packets_M,
                        packet.AuxData.lan_rx_packets_M,
                        packet.AuxData.lan_udp_tx_packets_M,
                        packet.AuxData.lan_udp_rx_packets_M);
    Remote_setTrackerMessage(packet.AuxData.new_message ||
                             packet.AuxData.message_received,
                             packet.AuxData.msg_resp_M,
                             packet.AuxData.Time_Hour_M,
                             packet.AuxData.Time_Minute_M);
}

void RS485Display_setup()
{
    pinMode(RS485_DE_PIN, OUTPUT);
    rs485SetTX(false);
    RS485_SERIAL.setRxBufferSize(2048);
    RS485_SERIAL.setTxBufferSize(2048);
    RS485_SERIAL.begin(RS485_BAUD, RS485_CONFIG, RS485_RX_PIN, RS485_TX_PIN);
    Serial.print(F("[RS485] field decoder payload32/payload64="));
    Serial.print(sizeof(base_packet_wire_t)); Serial.print('/');
    Serial.println(sizeof(base_packet_wire64_t));
    Serial.println(F("[RS485] Frame length detected by footer and verified by CRC16"));
}

void RS485Display_loop()
{
    full_packet_net_t packet = {};
    uint8_t button1 = 0;
    uint8_t button2 = 0;
    if (receivePacket_RS485(&packet, &button1, &button2))
    {
        applyPacket(packet);
        Serial.print(F("[RS485] RX OK payload/frame="));
        Serial.print(g_lastPayloadSize); Serial.print('/');
        Serial.print(g_lastFrameSize);
        Serial.print(g_lastWireFormat == WIRE_TIME_64 ? F(", time64") : F(", time32"));
        Serial.print(F(", #"));
        Serial.println(g_rxPackets);
        if (g_localButton != 0U || g_outAux.confirm_message_M) sendReply();
        return;
    }

    const uint32_t now = millis();
    if (g_lastDiagnosticMs == 0U ||
        (uint32_t)(now - g_lastDiagnosticMs) >= 2000UL)
    {
        g_lastDiagnosticMs = now;
        Serial.print(F("[RS485] waiting bytes/buffer/footer/lastPayload/crc/resync/accepted="));
        Serial.print(g_rxBytes); Serial.print('/');
        Serial.print(g_rxBuffered); Serial.print('/');
        Serial.print(g_footerMatches); Serial.print('/');
        Serial.print(g_lastCandidatePayload); Serial.print('/');
        Serial.print(g_crcErrors); Serial.print('/');
        Serial.print(g_footerErrors); Serial.print('/');
        Serial.println(g_rxPackets);
    }
}

void RS485Display_fini()
{
    RS485_SERIAL.flush();
    RS485_SERIAL.end();
}

void rxTask(void* parameter)
{
    (void)parameter;
    for (;;)
    {
        RS485Display_loop();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}

void RS485Display_setOutgoingAux(const aux_t* auxiliary)
{
    if (auxiliary) g_outAux = *auxiliary;
}
void RS485Display_getOutgoingAux(aux_t* auxiliary)
{
    if (auxiliary) *auxiliary = g_outAux;
}
void RS485Display_getIncomingAux(aux_t* auxiliary, uint8_t* button1, uint8_t* button2)
{
    if (auxiliary) *auxiliary = g_inAux;
    if (button1) *button1 = g_lastPacket.BUTTON1;
    if (button2) *button2 = g_lastPacket.BUTTON2;
}
bool RS485Display_hasIncomingButton() { return g_inButton != 0U; }
uint8_t RS485Display_takeIncomingButton()
{
    const uint8_t value = g_inButton;
    g_inButton = 0;
    return value;
}
void RS485Display_setLocalButtonEvent(uint8_t event)
{
    if (event >= 1U && event <= 3U) g_localButton = event;
}
uint32_t RS485Display_lastRxMs() { return g_lastRx; }
uint32_t RS485Display_rxPackets() { return g_rxPackets; }
uint32_t RS485Display_txPackets() { return g_txPackets; }
size_t RS485Display_payloadSize()
{
    return g_lastPayloadSize ? g_lastPayloadSize : sizeof(base_packet_wire_t);
}
size_t RS485Display_frameSize()
{
    return g_lastFrameSize ? g_lastFrameSize : sizeof(base_packet_wire_t) + 10U;
}

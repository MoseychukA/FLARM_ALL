GL050001C0-40 TFT + Wi-Fi DIAGNOSTIC TEST 12 FOR ESP32-S3
=========================================================

This diagnostic build is based directly on stable version 07. Display
timings, Wi-Fi operation, WEB switching, framebuffer mode and the 60-line
bounce buffer are unchanged.

Arduino IDE settings:

Board:                 ESP32S3 Dev Module
Arduino-ESP32:         3.x (required; do not compile with 2.0.11)
USB CDC On Boot:       Disabled
Flash Size:            16MB
PSRAM:                 OPI PSRAM
Partition Scheme:      any suitable 16MB scheme
Upload Mode:           UART0 / external USB-UART

Important:

1. GPIO19 is used as LCD VSYNC. Native USB uses GPIO19/20 and therefore
   must not be used while the display is connected.
2. GPIO46 is input-only and is used for POWER_SENSE.
3. Panel DISP (pin 31) is connected to 3.3V through a 10k resistor.
4. Backlight must be powered through the AP3032 driver. GPIO21 controls
   only the AP3032 CTRL/EN input.
5. The framebuffer needs working 8MB OPI PSRAM.
6. The sketch cycles through color bars, a geometry grid, an RGB gradient,
   and red/green/blue/white/black full-screen tests.

Wi-Fi WEB test:

Mode:                  Access Point
SSID:                  Тест+XXXXXX (6 hexadecimal module digits)
Password:              12345678
WEB address:           http://192.168.1.1/

The WEB page shows Wi-Fi status, connected client count, free RAM/PSRAM,
and buttons for selecting the TFT test image. The unique module suffix is
formed from the lower 24 bits of the ESP32-S3 eFuse MAC address.

LCD timing:

Resolution:            800x480
PCLK:                  24 MHz
HSYNC pulse/back/front: 64 / 80 / 42
VSYNC pulse/back/front: 2 / 74 / 1

If the image is shifted, unstable, or colors are wrong, first re-check the
FPC pin numbering and RGB bit order. Do not connect VLED pins directly to
ESP32-S3 or 3.3V.

Version 02 changes:

- Fixed continuous full-frame gradient updates that overloaded RGB DMA.
- Reduced RGB PCLK from 24 MHz to 16 MHz for stable operation with Wi-Fi.
- Added a WEB-selectable smooth-font screen in five different sizes.
- Font edges use bilinear coverage and RGB565 alpha blending.

Version 03 synchronization fix:

- Video analysis confirmed RGB DMA underflow, not wrong HSYNC/VSYNC polarity.
- Enabled a 20-line RGB bounce buffer in internal SRAM.
- The full framebuffer remains in 8MB OPI PSRAM.
- Restored the 24 MHz PCLK measured on the original AMT630A board.
- Arduino-ESP32 3.x is mandatory because 2.0.11 has no RGB bounce-buffer
  configuration field.

Version 04 changes:

- Access point is fully reset before startup.
- Fixed Wi-Fi channel 6, visible SSID, maximum 4 clients.
- Added wildcard DNS and captive-portal handlers.
- Disabled Wi-Fi power saving for reliable local WEB access.
- SSID now contains the requested literal plus sign: Тест+XXXXXX.
- Replaced the extreme-edge outline with an inset black/white calibration
  frame and magenta corner markers.

Version 05 changes:

- Corrected cyclic vertical displacement of the active image.
- Increased VSYNC back porch from 34 to 54 lines.
- Reduced VSYNC front porch from 38 to 18 lines.
- The total vertical period is unchanged.
- Replaced the multi-line calibration border with one cyan frame and four
  filled yellow corner squares.
- WEB interface from version 04 is unchanged.

Version 06 changes:

- Version 05 photographs showed approximately 18-20 remaining lines of
  upward cyclic displacement.
- Increased VSYNC back porch from 54 to 74 lines.
- Set VSYNC front porch to 1 line.
- Active RGB data is delayed by another 20 lines relative to VSYNC.
- WEB interface and RGB SRAM bounce buffer are unchanged.

Version 07 changes:

- WEB-triggered frame transmission is synchronized to the VSYNC event.
- Added a FreeRTOS semaphore signalled by the RGB VSYNC callback.
- Increased internal-SRAM bounce buffer from 20 to 60 display lines.
- The correction prevents PSRAM traffic during WEB switching from restarting
  RGB output with the old upward vertical displacement.
- Vertical timing 2 / 74 / 1 and the WEB settings are unchanged.

Diagnostic version 12 additions:

- VSYNC callback count.
- Minimum and maximum measured VSYNC period in microseconds.
- Number of VSYNC wait timeouts.
- Last and maximum screen rendering time.
- Last and maximum esp_lcd_panel_draw_bitmap() time.
- Free internal heap and free PSRAM.
- Connected Wi-Fi client count.
- WEB command count and time since the last WEB command.
- One compact DIAG line is printed every five seconds at 115200 baud.

Example:

D,t=10000,v=437,dv=219,p=22800/22920,to=0,r=4500/42000,d=1200/1700,h=180000,ps=6200000,c=1,w=2,wa=3100

Field meanings:

t=time ms, v=VSYNC total, dv=VSYNC during last 5 s, p=min/max VSYNC us,
to=VSYNC timeouts, r=last/max render us, d=last/max draw call us,
h=free heap, ps=free PSRAM, c=Wi-Fi clients, w=WEB commands,
wa=milliseconds since last WEB command.

The UART line is written only when enough transmit-buffer space is available;
diagnostics never wait for Serial output.

For diagnosis, copy Serial Monitor output starting at boot and include at
least 15 seconds before a synchronization failure and 15 seconds after it.
Do not change Serial speed from 115200.

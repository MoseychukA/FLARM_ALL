/*
  GL050001C0-40 / ESP32-S3 RGB TFT test
  Board: ESP32S3 Dev Module
  Arduino-ESP32: 2.0.11 or compatible 2.x

  Panel configuration taken from the working AMT630A timing measurements:
  800x480, RGB565, PCLK 24 MHz.
*/

#include <Arduino.h>
#include <math.h>
#include <WiFi.h>
#include <WebServer.h>
#include <esp_heap_caps.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_rgb.h>
#include <esp_err.h>

// RGB565 data pins: data_gpio_nums[0..15] = B0..B4, G0..G5, R0..R4.
// These correspond to the panel's B3..B7, G2..G7, R3..R7.
static constexpr int LCD_B3 = 1;
static constexpr int LCD_B4 = 2;
static constexpr int LCD_B5 = 3;
static constexpr int LCD_B6 = 4;
static constexpr int LCD_B7 = 5;
static constexpr int LCD_G2 = 6;
static constexpr int LCD_G3 = 7;
static constexpr int LCD_G4 = 10;
static constexpr int LCD_G5 = 11;
static constexpr int LCD_G6 = 12;
static constexpr int LCD_G7 = 13;
static constexpr int LCD_R3 = 14;
static constexpr int LCD_R4 = 15;
static constexpr int LCD_R5 = 16;
static constexpr int LCD_R6 = 17;
static constexpr int LCD_R7 = 18;

static constexpr int LCD_PCLK  = 48;
static constexpr int LCD_HSYNC = 47;
static constexpr int LCD_VSYNC = 19;  // GPIO46 cannot be used: it is input-only
static constexpr int LCD_DE    = 45;
static constexpr int LCD_BL_EN = 21;
static constexpr int POWER_SENSE = 46;

static constexpr int LCD_WIDTH  = 800;
static constexpr int LCD_HEIGHT = 480;

static esp_lcd_panel_handle_t panel = nullptr;
static uint16_t *frameBuffer = nullptr;
static WebServer webServer(80);
static String accessPointName;

enum TestScreen : uint8_t {
  SCREEN_COLOR_BARS,
  SCREEN_GRID,
  SCREEN_GRADIENT,
  SCREEN_RED,
  SCREEN_GREEN,
  SCREEN_BLUE,
  SCREEN_WHITE,
  SCREEN_BLACK,
  SCREEN_FONTS,
  SCREEN_AUTOMATIC
};

static TestScreen selectedScreen = SCREEN_AUTOMATIC;
static TestScreen displayedScreen = SCREEN_BLACK;
static uint8_t automaticStep = 0;
static uint32_t nextAutomaticChange = 0;

static constexpr uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b) {
  return static_cast<uint16_t>(((r & 0xF8) << 8) |
                               ((g & 0xFC) << 3) |
                               (b >> 3));
}

static void fill(uint16_t color) {
  for (size_t i = 0; i < static_cast<size_t>(LCD_WIDTH) * LCD_HEIGHT; ++i) {
    frameBuffer[i] = color;
  }
}

static void rectangle(int x, int y, int w, int h, uint16_t color) {
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > LCD_WIDTH)  w = LCD_WIDTH - x;
  if (y + h > LCD_HEIGHT) h = LCD_HEIGHT - y;
  if (w <= 0 || h <= 0) return;
  for (int row = y; row < y + h; ++row) {
    uint16_t *dst = frameBuffer + row * LCD_WIDTH + x;
    for (int col = 0; col < w; ++col) dst[col] = color;
  }
}

static void outline(int x, int y, int w, int h, int thickness, uint16_t color) {
  rectangle(x, y, w, thickness, color);
  rectangle(x, y + h - thickness, w, thickness, color);
  rectangle(x, y, thickness, h, color);
  rectangle(x + w - thickness, y, thickness, h, color);
}

static void showFrame() {
  esp_err_t err = esp_lcd_panel_draw_bitmap(panel, 0, 0, LCD_WIDTH, LCD_HEIGHT,
                                             frameBuffer);
  if (err != ESP_OK) {
    Serial.printf("draw_bitmap error: %s\n", esp_err_to_name(err));
  }
}

static void drawColorBars() {
  static const uint16_t colors[] = {
    rgb565(255, 255, 255), rgb565(255, 255, 0), rgb565(0, 255, 255),
    rgb565(0, 255, 0), rgb565(255, 0, 255), rgb565(255, 0, 0),
    rgb565(0, 0, 255), rgb565(0, 0, 0)
  };
  const int barWidth = LCD_WIDTH / 8;
  for (int i = 0; i < 8; ++i) {
    rectangle(i * barWidth, 0, (i == 7) ? LCD_WIDTH - i * barWidth : barWidth,
              LCD_HEIGHT, colors[i]);
  }
  outline(0, 0, LCD_WIDTH, LCD_HEIGHT, 4, rgb565(255, 255, 255));
}

static void drawGrid() {
  fill(rgb565(0, 0, 0));
  const uint16_t gray = rgb565(80, 80, 80);
  for (int x = 0; x < LCD_WIDTH; x += 50) rectangle(x, 0, 1, LCD_HEIGHT, gray);
  for (int y = 0; y < LCD_HEIGHT; y += 40) rectangle(0, y, LCD_WIDTH, 1, gray);
  outline(0, 0, LCD_WIDTH, LCD_HEIGHT, 4, rgb565(255, 255, 255));
  outline(50, 40, LCD_WIDTH - 100, LCD_HEIGHT - 80, 3, rgb565(255, 255, 0));
  outline(100, 80, LCD_WIDTH - 200, LCD_HEIGHT - 160, 3, rgb565(0, 255, 255));
  rectangle(LCD_WIDTH / 2 - 2, 0, 4, LCD_HEIGHT, rgb565(255, 0, 0));
  rectangle(0, LCD_HEIGHT / 2 - 2, LCD_WIDTH, 4, rgb565(255, 0, 0));
}

static void drawGradient() {
  for (int y = 0; y < LCD_HEIGHT; ++y) {
    for (int x = 0; x < LCD_WIDTH; ++x) {
      const uint8_t r = static_cast<uint8_t>((x * 255) / (LCD_WIDTH - 1));
      const uint8_t g = static_cast<uint8_t>((y * 255) / (LCD_HEIGHT - 1));
      const uint8_t b = static_cast<uint8_t>(((x + y) * 255) /
                                             (LCD_WIDTH + LCD_HEIGHT - 2));
      frameBuffer[y * LCD_WIDTH + x] = rgb565(r, g, b);
    }
  }
  outline(0, 0, LCD_WIDTH, LCD_HEIGHT, 4, rgb565(255, 255, 255));
}

// Compact 5x7 test font. Bilinear scaling and RGB565 blending smooth
// the glyph edges at every requested size.
static const uint8_t *glyph5x7(char c) {
  static const uint8_t blank[7] = {0,0,0,0,0,0,0};
  static const uint8_t A[7] = {14,17,17,31,17,17,17};
  static const uint8_t E[7] = {31,16,16,30,16,16,31};
  static const uint8_t F[7] = {31,16,16,30,16,16,16};
  static const uint8_t H[7] = {17,17,17,31,17,17,17};
  static const uint8_t M[7] = {17,27,21,21,17,17,17};
  static const uint8_t N[7] = {17,25,21,19,17,17,17};
  static const uint8_t O[7] = {14,17,17,17,17,17,14};
  static const uint8_t P[7] = {30,17,17,30,16,16,16};
  static const uint8_t S[7] = {15,16,16,14,1,1,30};
  static const uint8_t T[7] = {31,4,4,4,4,4,4};
  static const uint8_t X[7] = {17,17,10,4,10,17,17};
  static const uint8_t n1[7] = {4,12,4,4,4,4,14};
  static const uint8_t n2[7] = {14,17,1,2,4,8,31};
  static const uint8_t n3[7] = {30,1,1,14,1,1,30};
  static const uint8_t n4[7] = {2,6,10,18,31,2,2};
  static const uint8_t n5[7] = {31,16,16,30,1,1,30};
  static const uint8_t n6[7] = {14,16,16,30,17,17,14};
  switch (c) {
    case 'A': return A; case 'E': return E; case 'F': return F;
    case 'H': return H; case 'M': return M; case 'N': return N;
    case 'O': return O; case 'P': return P; case 'S': return S;
    case 'T': return T; case 'X': return X;
    case '1': return n1; case '2': return n2; case '3': return n3;
    case '4': return n4; case '5': return n5; case '6': return n6;
    default: return blank;
  }
}

static uint16_t blend565(uint16_t bg, uint16_t fg, uint8_t alpha) {
  const uint16_t inv = 255 - alpha;
  const uint8_t br = ((bg >> 11) & 31) * 255 / 31;
  const uint8_t bgc = ((bg >> 5) & 63) * 255 / 63;
  const uint8_t bb = (bg & 31) * 255 / 31;
  const uint8_t fr = ((fg >> 11) & 31) * 255 / 31;
  const uint8_t fgc = ((fg >> 5) & 63) * 255 / 63;
  const uint8_t fb = (fg & 31) * 255 / 31;
  return rgb565((br * inv + fr * alpha) / 255,
                (bgc * inv + fgc * alpha) / 255,
                (bb * inv + fb * alpha) / 255);
}

static uint8_t glyphPixel(const uint8_t *rows, int x, int y) {
  if (x < 0 || x >= 5 || y < 0 || y >= 7) return 0;
  return (rows[y] & (1U << (4 - x))) ? 255 : 0;
}

static void smoothChar(int x0, int y0, char c, int height, uint16_t color) {
  const uint8_t *rows = glyph5x7(c);
  const int width = (height * 5 + 3) / 7;
  for (int y = 0; y < height; ++y) {
    const float sy = ((y + 0.5f) * 7.0f / height) - 0.5f;
    const int iy = floorf(sy);
    const float fy = sy - iy;
    for (int x = 0; x < width; ++x) {
      const float sx = ((x + 0.5f) * 5.0f / width) - 0.5f;
      const int ix = floorf(sx);
      const float fx = sx - ix;
      const float a0 = glyphPixel(rows, ix, iy) * (1.0f - fx) + glyphPixel(rows, ix + 1, iy) * fx;
      const float a1 = glyphPixel(rows, ix, iy + 1) * (1.0f - fx) + glyphPixel(rows, ix + 1, iy + 1) * fx;
      const uint8_t alpha = static_cast<uint8_t>(a0 * (1.0f - fy) + a1 * fy);
      const int px = x0 + x;
      const int py = y0 + y;
      if (alpha && px >= 0 && px < LCD_WIDTH && py >= 0 && py < LCD_HEIGHT) {
        uint16_t &dst = frameBuffer[py * LCD_WIDTH + px];
        dst = blend565(dst, color, alpha);
      }
    }
  }
}

static void smoothText(int x, int y, const char *text, int height, uint16_t color) {
  const int charWidth = (height * 5 + 3) / 7;
  const int advance = charWidth + max(2, height / 7);
  while (*text) {
    if (*text != ' ') smoothChar(x, y, *text, height, color);
    x += advance;
    ++text;
  }
}

static void drawFontTest() {
  fill(rgb565(8, 15, 28));
  smoothText(28, 22,  "SMOOTH FONT 16 PX", 16, rgb565(210, 225, 255));
  smoothText(28, 70,  "SMOOTH FONT 24 PX", 24, rgb565(80, 220, 255));
  smoothText(28, 135, "SMOOTH FONT 36 PX", 36, rgb565(255, 220, 70));
  smoothText(28, 225, "SMOOTH FONT",       52, rgb565(255, 110, 100));
  smoothText(28, 335, "ESP32 S3",          64, rgb565(100, 255, 150));
  outline(0, 0, LCD_WIDTH, LCD_HEIGHT, 4, rgb565(255, 255, 255));
}

static const char *screenName(TestScreen screen) {
  switch (screen) {
    case SCREEN_COLOR_BARS: return "Цветные полосы";
    case SCREEN_GRID:       return "Сетка";
    case SCREEN_GRADIENT:   return "RGB-градиент";
    case SCREEN_RED:        return "Красный";
    case SCREEN_GREEN:      return "Зелёный";
    case SCREEN_BLUE:       return "Синий";
    case SCREEN_WHITE:      return "Белый";
    case SCREEN_BLACK:      return "Чёрный";
    case SCREEN_FONTS:      return "Плавные шрифты";
    default:                return "Автоматический тест";
  }
}

static void displayScreen(TestScreen screen) {
  // Avoid repeatedly copying a full frame. Continuous gradient redraw used
  // to starve RGB DMA as soon as Wi-Fi also accessed PSRAM.
  if (screen == displayedScreen) return;
  switch (screen) {
    case SCREEN_COLOR_BARS: drawColorBars(); break;
    case SCREEN_GRID:       drawGrid(); break;
    case SCREEN_GRADIENT:   drawGradient(); break;
    case SCREEN_RED:        fill(rgb565(255, 0, 0)); break;
    case SCREEN_GREEN:      fill(rgb565(0, 255, 0)); break;
    case SCREEN_BLUE:       fill(rgb565(0, 0, 255)); break;
    case SCREEN_WHITE:      fill(rgb565(255, 255, 255)); break;
    case SCREEN_BLACK:      fill(rgb565(0, 0, 0)); break;
    case SCREEN_FONTS:      drawFontTest(); break;
    default: return;
  }
  showFrame();
  displayedScreen = screen;
  Serial.printf("TFT: %s\n", screenName(screen));
}

static String makeHtml() {
  String html;
  html.reserve(5000);
  html += F("<!doctype html><html lang='ru'><head><meta charset='utf-8'>");
  html += F("<meta name='viewport' content='width=device-width,initial-scale=1'>");
  html += F("<meta http-equiv='refresh' content='10'><title>ESP32-S3 TFT</title>");
  html += F("<style>body{font-family:Arial,sans-serif;max-width:760px;margin:25px auto;padding:0 16px;background:#101820;color:#eef}h1{font-size:25px}.box{background:#1d2a35;padding:16px;border-radius:12px;margin:12px 0}.ok{color:#65e572}.buttons{display:grid;grid-template-columns:repeat(2,1fr);gap:9px}a{display:block;text-align:center;text-decoration:none;color:white;background:#1769aa;padding:13px 5px;border-radius:8px}a:hover{background:#2385d0}small{color:#aab}code{color:#ffe082}</style></head><body>");
  html += F("<h1>GL050001C0-40 — тест ESP32-S3</h1><div class='box'><b class='ok'>Wi-Fi работает</b><br><br>Точка доступа: <code>");
  html += accessPointName;
  html += F("</code><br>IP-адрес: <code>");
  html += WiFi.softAPIP().toString();
  html += F("</code><br>Подключено клиентов: <code>");
  html += String(WiFi.softAPgetStationNum());
  html += F("</code><br>Свободная RAM: <code>");
  html += String(ESP.getFreeHeap());
  html += F(" байт</code><br>Свободная PSRAM: <code>");
  html += String(ESP.getFreePsram());
  html += F(" байт</code><br>Экран: <code>");
  html += screenName(selectedScreen);
  html += F("</code></div><div class='box'><h2>Изображение TFT</h2><div class='buttons'>");
  html += F("<a href='/set?screen=auto'>Автоматически</a><a href='/set?screen=bars'>Цветные полосы</a>");
  html += F("<a href='/set?screen=grid'>Сетка</a><a href='/set?screen=gradient'>RGB-градиент</a>");
  html += F("<a href='/set?screen=red'>Красный</a><a href='/set?screen=green'>Зелёный</a>");
  html += F("<a href='/set?screen=blue'>Синий</a><a href='/set?screen=white'>Белый</a>");
  html += F("<a href='/set?screen=black'>Чёрный</a><a href='/set?screen=fonts'>Плавные шрифты</a></div></div>");
  html += F("<small>FlyRf TFT Wi-Fi test 02 · страница обновляется каждые 10 секунд</small></body></html>");
  return html;
}

static void handleSetScreen() {
  const String value = webServer.arg("screen");
  if      (value == "bars")     selectedScreen = SCREEN_COLOR_BARS;
  else if (value == "grid")     selectedScreen = SCREEN_GRID;
  else if (value == "gradient") selectedScreen = SCREEN_GRADIENT;
  else if (value == "red")      selectedScreen = SCREEN_RED;
  else if (value == "green")    selectedScreen = SCREEN_GREEN;
  else if (value == "blue")     selectedScreen = SCREEN_BLUE;
  else if (value == "white")    selectedScreen = SCREEN_WHITE;
  else if (value == "black")    selectedScreen = SCREEN_BLACK;
  else if (value == "fonts")    selectedScreen = SCREEN_FONTS;
  else                            selectedScreen = SCREEN_AUTOMATIC;

  if (selectedScreen == SCREEN_AUTOMATIC) {
    automaticStep = 0;
    nextAutomaticChange = 0;
  } else {
    displayScreen(selectedScreen);
  }
  webServer.sendHeader("Location", "/", true);
  webServer.send(303, "text/plain", "");
}

static void initWiFiWeb() {
  const uint32_t moduleNumber = static_cast<uint32_t>(ESP.getEfuseMac() & 0xFFFFFFULL);
  char suffix[7];
  snprintf(suffix, sizeof(suffix), "%06X", moduleNumber);
  accessPointName = String("Тест") + suffix;

  WiFi.mode(WIFI_AP);
  const IPAddress ip(192, 168, 1, 1);
  const IPAddress mask(255, 255, 255, 0);
  if (!WiFi.softAPConfig(ip, ip, mask)) Serial.println("WiFi AP IP configuration failed");
  if (!WiFi.softAP(accessPointName.c_str(), "12345678")) {
    Serial.println("WiFi AP start failed");
    return;
  }

  webServer.on("/", HTTP_GET, []() { webServer.send(200, "text/html; charset=utf-8", makeHtml()); });
  webServer.on("/set", HTTP_GET, handleSetScreen);
  webServer.onNotFound([]() { webServer.sendHeader("Location", "/", true); webServer.send(302); });
  webServer.begin();
  Serial.printf("WiFi AP: %s\n", accessPointName.c_str());
  Serial.println("Password: 12345678");
  Serial.println("WEB: http://192.168.1.1/");
}

static bool initDisplay() {
  pinMode(LCD_BL_EN, OUTPUT);
  digitalWrite(LCD_BL_EN, LOW);
  pinMode(POWER_SENSE, INPUT); // GPIO46 has no usable internal pull-up

  frameBuffer = static_cast<uint16_t *>(heap_caps_malloc(
      LCD_WIDTH * LCD_HEIGHT * sizeof(uint16_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!frameBuffer) {
    Serial.println("ERROR: PSRAM framebuffer allocation failed");
    return false;
  }

  esp_lcd_rgb_panel_config_t config = {};
  config.clk_src = LCD_CLK_SRC_PLL160M;
  // Wi-Fi and RGB DMA share access to external PSRAM. At 16 MHz RGB565
  // needs about 32 MB/s instead of 48 MB/s at the previous 24 MHz setting.
  config.timings.pclk_hz = 16000000;
  config.timings.h_res = LCD_WIDTH;
  config.timings.v_res = LCD_HEIGHT;
  config.timings.hsync_pulse_width = 64;
  config.timings.hsync_back_porch = 80;
  config.timings.hsync_front_porch = 42;
  config.timings.vsync_pulse_width = 2;
  config.timings.vsync_back_porch = 34;
  config.timings.vsync_front_porch = 38;
  config.timings.flags.pclk_active_neg = false;
  config.data_width = 16;
  config.psram_trans_align = 64;
  config.hsync_gpio_num = LCD_HSYNC;
  config.vsync_gpio_num = LCD_VSYNC;
  config.de_gpio_num = LCD_DE;
  config.pclk_gpio_num = LCD_PCLK;
  config.disp_gpio_num = -1; // panel DISP is pulled up to 3.3 V through 10k
  config.data_gpio_nums[0]  = LCD_B3;
  config.data_gpio_nums[1]  = LCD_B4;
  config.data_gpio_nums[2]  = LCD_B5;
  config.data_gpio_nums[3]  = LCD_B6;
  config.data_gpio_nums[4]  = LCD_B7;
  config.data_gpio_nums[5]  = LCD_G2;
  config.data_gpio_nums[6]  = LCD_G3;
  config.data_gpio_nums[7]  = LCD_G4;
  config.data_gpio_nums[8]  = LCD_G5;
  config.data_gpio_nums[9]  = LCD_G6;
  config.data_gpio_nums[10] = LCD_G7;
  config.data_gpio_nums[11] = LCD_R3;
  config.data_gpio_nums[12] = LCD_R4;
  config.data_gpio_nums[13] = LCD_R5;
  config.data_gpio_nums[14] = LCD_R6;
  config.data_gpio_nums[15] = LCD_R7;
  config.flags.fb_in_psram = true;

  esp_err_t err = esp_lcd_new_rgb_panel(&config, &panel);
  if (err != ESP_OK) {
    Serial.printf("esp_lcd_new_rgb_panel failed: %s\n", esp_err_to_name(err));
    return false;
  }
  if ((err = esp_lcd_panel_reset(panel)) != ESP_OK ||
      (err = esp_lcd_panel_init(panel)) != ESP_OK) {
    Serial.printf("LCD init failed: %s\n", esp_err_to_name(err));
    return false;
  }

  fill(rgb565(0, 0, 0));
  showFrame();
  digitalWrite(LCD_BL_EN, HIGH);
  return true;
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("GL050001C0-40 TFT test");
  Serial.printf("PSRAM size: %u bytes\n", ESP.getPsramSize());
  Serial.printf("Power sense GPIO46: %s\n", digitalRead(POWER_SENSE) ? "HIGH" : "LOW");

  if (!initDisplay()) {
    Serial.println("Display initialization stopped");
    while (true) delay(1000);
  }
  Serial.println("Display initialized");
  initWiFiWeb();
}

void loop() {
  webServer.handleClient();

  if (selectedScreen != SCREEN_AUTOMATIC) {
    displayScreen(selectedScreen);
  } else if (static_cast<int32_t>(millis() - nextAutomaticChange) >= 0) {
    static const TestScreen sequence[] = {
      SCREEN_COLOR_BARS, SCREEN_GRID, SCREEN_GRADIENT,
      SCREEN_FONTS, SCREEN_RED, SCREEN_GREEN, SCREEN_BLUE,
      SCREEN_WHITE, SCREEN_BLACK
    };
    displayScreen(sequence[automaticStep]);
    automaticStep = (automaticStep + 1) % (sizeof(sequence) / sizeof(sequence[0]));
    nextAutomaticChange = millis() + 5000;
  }

  delay(2);
}

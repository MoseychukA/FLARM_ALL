#include "config.h"
#include <LittleFS.h>
const char* profile_name(Profile p){ switch(p){ case Profile::Normal: return "Normal"; case Profile::HighEMI: return "High-EMI"; case Profile::Urban: return "Urban"; default: return "Remote"; } }
void load_config(struct Config &cfg){ if(LittleFS.exists("/config.txt")){ File f=LittleFS.open("/config.txt","r"); if(f){ while(f.available()){ String line=f.readStringUntil('
'); line.trim(); if(!line.length()||line[0]=='#') continue; int eq=line.indexOf('='); if(eq<0) continue; String k=line.substring(0,eq), v=line.substring(eq+1); k.trim(); v.trim(); if(k=="output_raw") cfg.output_raw=(v=="1"||v=="true"||v=="on"); else if(k=="out_format") cfg.out_format=v.toInt(); } f.close(); } } }
void save_config(const struct Config &cfg){ File f=LittleFS.open("/config.txt","w"); if(!f) return; f.printf("output_raw=%d
", cfg.output_raw?1:0); f.printf("out_format=%d
", cfg.out_format); f.close(); }
void print_config(const struct Config &cfg){ Serial.printf("Profile=%s RAW=%d outfmt=%d
", profile_name(cfg.profile), cfg.output_raw?1:0, cfg.out_format); }

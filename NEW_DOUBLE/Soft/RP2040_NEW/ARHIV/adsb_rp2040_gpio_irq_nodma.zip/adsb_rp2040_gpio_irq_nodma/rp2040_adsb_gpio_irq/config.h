#pragma once
#include <Arduino.h>
enum class Profile{ Normal, HighEMI, Urban, Remote };
struct Config{ Profile profile=Profile::Normal; bool output_raw=true; int out_format=0; };
const char* profile_name(Profile p);
void load_config(struct Config &cfg);
void save_config(const struct Config &cfg);
void print_config(const struct Config &cfg);

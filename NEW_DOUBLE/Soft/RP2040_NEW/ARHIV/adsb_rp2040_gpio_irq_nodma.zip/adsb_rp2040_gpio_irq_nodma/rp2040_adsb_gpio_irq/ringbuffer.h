#pragma once
#include <Arduino.h>
#include <vector>
#include <string.h>
#include <atomic>

struct RawMessage{ uint8_t channel; uint8_t payload[14]; uint8_t bytes; uint16_t bits; uint32_t t0_us; };
class LockFreePacketQueue{ public: void begin(size_t cap){ capacity=1; while(capacity<cap) capacity<<=1; buf.resize(capacity); head=tail=0;} bool push(const RawMessage&m){ uint32_t h=head.load(std::memory_order_relaxed); uint32_t t=tail.load(std::memory_order_acquire); if(((h+1)&(capacity-1))==t) return false; buf[h]=m; head.store((h+1)&(capacity-1), std::memory_order_release); return true;} bool pop(RawMessage&m){ uint32_t t=tail.load(std::memory_order_relaxed); uint32_t h=head.load(std::memory_order_acquire); if(t==h) return false; m=buf[t]; tail.store((t+1)&(capacity-1), std::memory_order_release); return true;} private: std::vector<RawMessage> buf; std::atomic<uint32_t> head{0}, tail{0}; uint32_t capacity{0}; };

// Edge timestamp buffer per channel (GPIO IRQ writes here)
struct Edge { uint32_t t; uint8_t level; };
static const int EDGE_BUF_SIZE = 4096;
struct EdgeBuf { volatile uint16_t widx=0, ridx=0; Edge e[EDGE_BUF_SIZE]; };
extern EdgeBuf g_edge[3];

// Correlator API (edge-based)
struct Config;
int run_edge_correlator_and_slice(int ch, const struct Config &cfg, LockFreePacketQueue &outq);

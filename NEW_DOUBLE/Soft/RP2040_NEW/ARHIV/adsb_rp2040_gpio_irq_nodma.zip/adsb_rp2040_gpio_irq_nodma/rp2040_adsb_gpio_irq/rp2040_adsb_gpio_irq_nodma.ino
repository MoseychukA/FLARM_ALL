// rp2040_adsb_gpio_irq_nodma.ino (inputs 17,19,22 via GPIO IRQ)
#include <Arduino.h>
#include <LittleFS.h>
#include <hardware/gpio.h>
#include <pico/multicore.h>
#include "ringbuffer.h"
#include "adsb_decoder.h"
#include "config.h"
#include "esp_packet.h"
#include "utils.h"

static constexpr uint8_t PIN_CH1 = 17;
static constexpr uint8_t PIN_CH2 = 19;
static constexpr uint8_t PIN_CH3 = 22;
static constexpr uint8_t UART2_TX = 4; static constexpr uint8_t UART2_RX = 5;
static constexpr uint8_t PIN_BLINK_CORE0 = 15; static constexpr uint8_t PIN_BLINK_CORE1 = 25;

static LockFreePacketQueue pktq[3];
static Config g_cfg; static String cmd_line;

static uint32_t crc32_(const uint8_t* data, size_t len){ uint32_t crc=0xFFFFFFFF; for(size_t i=0;i<len;i++){ crc^=data[i]; for(int j=0;j<8;j++) crc=(crc>>1) ^ (0xEDB88320 & (-(int)(crc&1))); } return ~crc; }

EdgeBuf g_edge[3];

static inline uint8_t pin_to_ch(uint gpio){ return (gpio==PIN_CH1)?0 : (gpio==PIN_CH2)?1 : (gpio==PIN_CH3)?2 : 255; }

static void gpio_irq_handler(uint gpio, uint32_t events){ uint8_t ch = pin_to_ch(gpio); if (ch>2) return; uint32_t t=time_us_32(); uint8_t lvl = (events & GPIO_IRQ_EDGE_RISE)?1:0; uint16_t wi = g_edge[ch].widx; g_edge[ch].e[wi].t=t; g_edge[ch].e[wi].level=lvl; g_edge[ch].widx = (wi+1) & (EDGE_BUF_SIZE-1); }

void core1_entry(){ uint32_t last=time_us_32(); while(true){ uint32_t t=time_us_32(); if(t-last>500000){ last=t; sio_hw->gpio_togl=(1u<<PIN_BLINK_CORE1);} tight_loop_contents(); } }

static void send_to_esp32(const FlightOutput &fo){ struct __attribute__((packed)) Frame{ uint8_t sof[2]; uint16_t len; FlightOutput fo; uint32_t crc; } f; f.sof[0]=0x55; f.sof[1]=0xAA; f.len=sizeof(FlightOutput); memcpy(&f.fo,&fo,sizeof(FlightOutput)); f.crc=crc32_((uint8_t*)&f.fo,sizeof(FlightOutput)); Serial2.write((uint8_t*)&f,sizeof(f)); }

static void emit_debug_raw(const RawMessage &rm){ Serial.print("CH"); Serial.print(rm.channel+1); Serial.print(" "); Serial.print(rm.bits); Serial.print("b "); for(size_t i=0;i<rm.bytes;i++){ if(i) Serial.print(' '); char buf[4]; sprintf(buf, "%02X", rm.payload[i]); Serial.print(buf);} Serial.println(); }

static void process_packets(){ RawMessage rm; DecodedFrame df; for (int i=0;i<3;i++){ while (pktq[i].pop(rm)){
    if (g_cfg.output_raw) emit_debug_raw(rm);
    CrcStatus cs = check_and_fix_crc(rm);
    if (decode_adsb_frame(rm, df, g_cfg)){
      FlightOutput fo={0}; fo.addr=df.icao; fo.Squawk=df.squawk; memcpy(fo.flight, df.callsign, sizeof(fo.flight)); fo.altitude=df.altitude_m_geo; fo.pressure_altitude=df.altitude_m_baro; fo.speed=df.speed_kmh; fo.course=df.track_deg; fo.vert_rate=df.vert_rate_mpm; fo.latitude=df.lat; fo.longitude=df.lon; fo.seen=df.seen_time_ms; fo.timestamp=millis(); fo.signal_source=1; fo.aircraft_type=df.aircraft_type; send_to_esp32(fo);
    }
  }}
}

static void handle_cmd(const String &cmd){ String u=cmd; u.trim(); u.toUpperCase(); if(u=="HELP"){ Serial.println("Commands: HELP, SHOW, SAVE, LOAD, RAW ON|OFF"); return;} if(u=="SHOW"){ print_config(g_cfg); return;} if(u=="SAVE"){ save_config(g_cfg); Serial.println("Saved"); return;} if(u=="LOAD"){ load_config(g_cfg); Serial.println("Loaded"); return;} if(u=="RAW ON"){ g_cfg.output_raw=true; Serial.println("RAW=ON"); return;} if(u=="RAW OFF"){ g_cfg.output_raw=false; Serial.println("RAW=OFF"); return;} Serial.println("Unknown"); }

void setup(){ Serial.begin(115200); unsigned long t0=millis(); while(!Serial && !Serial.dtr() && (millis()-t0)<8000) delay(10); Serial.println("GPIO IRQ no-DMA start");
  LittleFS.begin(); load_config(g_cfg);
  gpio_init(PIN_BLINK_CORE0); gpio_set_dir(PIN_BLINK_CORE0, GPIO_OUT); gpio_put(PIN_BLINK_CORE0,0);
  gpio_init(PIN_BLINK_CORE1); gpio_set_dir(PIN_BLINK_CORE1, GPIO_OUT); gpio_put(PIN_BLINK_CORE1,0);

  Serial2.setTX(UART2_TX); Serial2.setRX(UART2_RX); Serial2.begin(921600);
  for(int i=0;i<3;i++) pktq[i].begin(64);

  // Inputs
  gpio_init(PIN_CH1); gpio_set_dir(PIN_CH1, GPIO_IN); gpio_pull_down(PIN_CH1);
  gpio_init(PIN_CH2); gpio_set_dir(PIN_CH2, GPIO_IN); gpio_pull_down(PIN_CH2);
  gpio_init(PIN_CH3); gpio_set_dir(PIN_CH3, GPIO_IN); gpio_pull_down(PIN_CH3);

  // IRQ
  gpio_set_irq_enabled_with_callback(PIN_CH1, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true, &gpio_irq_handler);
  gpio_set_irq_enabled(PIN_CH2, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true);
  gpio_set_irq_enabled(PIN_CH3, GPIO_IRQ_EDGE_RISE | GPIO_IRQ_EDGE_FALL, true);

  multicore_launch_core1(core1_entry);
  Serial.println("Setup done");
}

static uint32_t last_blink0=0; static uint32_t last_slice=0;
void loop(){ uint32_t now=millis(); if(now-last_blink0>1000){ last_blink0=now; sio_hw->gpio_togl=(1u<<PIN_BLINK_CORE0);} // try slicing periodically
  // Try edge-based correlator on each channel
  for (int i=0;i<3;i++) run_edge_correlator_and_slice(i, g_cfg, pktq[i]);
  process_packets();
  // USB commands
  while(Serial.available()){ char c=Serial.read(); if(c=='
'||c==''){ if(cmd_line.length()){ handle_cmd(cmd_line); cmd_line=""; } } else cmd_line+=c; }
}

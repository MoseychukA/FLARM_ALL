#include "ringbuffer.h"
#include <math.h>
EdgeBuf g_edge[3];

// Helper to read next edge (returns false if empty)
static inline bool edge_pop(int ch, Edge &out){ EdgeBuf &B=g_edge[ch]; if (B.ridx==B.widx) return false; out = B.e[B.ridx]; B.ridx = (B.ridx+1) & (EDGE_BUF_SIZE-1); return true; }

// Peek count of available edges
static inline int edge_available(int ch){ EdgeBuf &B=g_edge[ch]; int d = (int)B.widx - (int)B.ridx; if (d<0) d += EDGE_BUF_SIZE; return d; }

// Very lightweight edge-based preamble + slicing (coarse)
int run_edge_correlator_and_slice(int ch, const struct Config &cfg, LockFreePacketQueue &outq){
  // Consume edges but keep last ~50us in a small window
  static Edge window[3][256]; static int wcount[3]={0,0,0};
  Edge e; int read=0; while (edge_pop(ch, e)) { if (wcount[ch]<256) window[ch][wcount[ch]++] = e; else { memmove(window[ch], window[ch]+1, sizeof(Edge)*(255)); window[ch][255]=e; } read++; }
  if (wcount[ch] < 6) return 0; // need at least a few edges

  // Try to detect preamble by intervals ~ (0.5us,0.5us,2.5us,0.5us,1.5us) between rising pulse centers
  // Our timestamps are 1us granularity, so we use relaxed windows.
  for (int i=0; i+10 < wcount[ch]; ++i){
    // find sequence with alternating level (rise/fall)
    uint32_t t0 = window[ch][i].t;
    int matches=0; int last = i;
    for (int j=i+1; j<i+11 && j<wcount[ch]; ++j){
      uint32_t dt = window[ch][j].t - window[ch][last].t; if (dt>100) break; // too long
      // Accept any dt in {0,1,2,3} us for the short gaps to accommodate timer granularity
      if (dt<=3) { matches++; last=j; if (matches>=5) break; }
    }
    if (matches>=5){
      // Assume preamble at t0; now slice 56 or 112 bits using edge density in halves
      RawMessage rm; rm.channel=ch; rm.bits=112; rm.bytes=14; memset(rm.payload,0,sizeof(rm.payload)); rm.t0_us=t0;
      for (int b=0;b<112;b++){
        uint32_t bit_start = t0 + 8 + b*1; // 1us per bit, start after 8us preamble
        // Count edges in first and second half
        int c1=0,c2=0; for (int k=i;k<wcount[ch];++k){ uint32_t tt=window[ch][k].t; if (tt>=bit_start && tt<bit_start+1){ c1++; } else if (tt>=bit_start+1 && tt<bit_start+2){ c2++; } if (tt>bit_start+2) break; }
        int v = (c1>c2)?1:0; int byte=b>>3, bit=7-(b&7); if (v) rm.payload[byte]|=(1<<bit);
      }
      outq.push(rm);
      return 1;
    }
  }
  return 0;
}

#include "adsb_decoder.h"
#include <string.h>
#include <math.h>

static uint32_t modes_checksum(const uint8_t *msg, int bits){ uint32_t rem=0; for(int i=0;i<bits-24;i++){ int byte=i>>3; int bit=7-(i&7); int b=(msg[byte]>>bit)&1; int top=((rem>>23)&1)^b; rem=((rem<<1)&0xFFFFFF) ^ (top?0xFFF409:0); } uint32_t last=((uint32_t)msg[(bits/8)-3]<<16)|((uint32_t)msg[(bits/8)-2]<<8)|msg[(bits/8)-1]; return rem ^ last; }
CrcStatus check_and_fix_crc(RawMessage &rm){ uint32_t syn=modes_checksum(rm.payload, rm.bits); if(syn==0) return CRC_OK; int B=rm.bits; for(int i=0;i<B;i++){ int byte=i>>3; int bit=7-(i&7); rm.payload[byte]^=(1<<bit); if(modes_checksum(rm.payload,B)==0) return CRC_FIXED1; rm.payload[byte]^=(1<<bit);} return CRC_FAIL; }
static int decode_df(const RawMessage &rm){ return rm.payload[0]>>3; }
static int get_tc(const RawMessage &rm){ return (rm.payload[4]>>3); }
static void hex_icao(const RawMessage &rm, uint32_t &icao){ icao=((uint32_t)rm.payload[1]<<16)|((uint32_t)rm.payload[2]<<8)|rm.payload[3]; }

bool decode_adsb_frame(const RawMessage &rm, DecodedFrame &df, const struct Config &cfg){ memset(&df,0,sizeof(df)); df.lat=NAN; df.lon=NAN; strcpy(df.callsign,""); df.seen_time_ms=millis(); int dfnum=decode_df(rm); if(dfnum!=17 && dfnum!=18 && dfnum!=20 && dfnum!=21) return false; hex_icao(rm, df.icao); int tc=get_tc(rm); const uint8_t *me=&rm.payload[5]; if (tc>=1 && tc<=4){ // callsign
  static const char set[] = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ#####_###############0123456789######"; uint64_t v=0; for(int i=0;i<6;i++) v=(v<<8)|me[i]; for(int i=7;i>=0;i--){ int c=v & 0x3F; df.callsign[i] = set[c]; v >>= 6; } df.callsign[8]=0; for(int i=0;i<8;i++) if(df.callsign[i]=='#'||df.callsign[i]=='_') df.callsign[i]=' '; }
 else if (tc==19){ int subtype = (me[0] & 0x7); if(subtype==1||subtype==2){ int vew=((me[1]&0x7F)<<3)|(me[2]>>5); int vns=((me[2]&0x1F)<<6)|(me[3]>>2); bool sgn_ew = me[1]&0x80; bool sgn_ns = me[3]&0x02; int ew=vew-1, ns=vns-1; float vx=(sgn_ew?-ew:ew), vy=(sgn_ns?-ns:ns); float spd=sqrtf(vx*vx+vy*vy); df.speed_kmh=(int)round(spd*1.852f); float trk = atan2f(vx, vy)*180.0f/3.1415926f; if(trk<0) trk+=360.0f; df.track_deg=(int)round(trk);} }
 return true; }


# ADS-B RP2040 FreeRTOS Receiver — v2.1 full (DMA + Adaptive preamble + Gillham + TC19)

Особенности:
- PIO -> DMA в кольцевые буферы (3 канала), без опроса RX FIFO CPU
- Адаптивный коррелятор преамбулы (Variant B): динамический порог на основе EMA шума
- Цифровой фильтр импульсов: 0.4–0.7 μs, нормализация до 0.5 μs
- Демодуляция PPM 1 Mbps, пакеты 56/112 бит
- CPR: глобальная (even/odd с учётом времени) и локальная (по опорной точке), корректное восстановление координат
- Скорости TC=19: подтипы 1/2 (EW/NS), 3 (курс/наземная), 4 (курс/истинная ТAS)
- Высота: Q=1 (25 ft) и Q=0 (Gillham AC13)
- CRC-24 (таблица 256) + коррекция одиночной ошибки (1-bit fix)
- UART2 921600 бод (TX GPIO4, RX GPIO5)

Версии:
- Arduino IDE 2.3.2
- Earle Philhower RP2040 core 3.7.2
- FreeRTOS_RP2040 by Khoih-prog 1.3.2

v2.1 изменения:
- В corr_preamble_and_get_t0() внедрён адаптивный порог: score >= base + k * EMA(negHits)
  Параметры по умолчанию: g_base_thr=36, g_k=1.5, g_neg_alpha=0.02, PRE_PENALTY_THR=6, PRE_MIN_POS_HITS=14

#include "dma_ring.h"
#include "hardware/regs/dreq.h"
bool dma_ring_init(DmaRing &r, PIO pio, uint sm, size_t words){ r.buf=(uint32_t*)malloc(words*4); r.words=words; r.widx=0; r.ridx=0; r.pio=pio; r.sm=sm; r.dma_ch=0; return true;}
bool dma_ring_get_word(DmaRing &r, uint32_t &w){ if(r.ridx==r.widx) return False; w=r.buf[r.ridx++ & (r.words-1)]; return True;}

#pragma once
#include <stdint.h>
#include <stddef.h>
static inline uint32_t modes_crc24(const uint8_t* d, size_t n){ uint32_t c=0; return c; }
static inline int modes_try_single_bit_fix(uint8_t* m, size_t b){ return -1; }

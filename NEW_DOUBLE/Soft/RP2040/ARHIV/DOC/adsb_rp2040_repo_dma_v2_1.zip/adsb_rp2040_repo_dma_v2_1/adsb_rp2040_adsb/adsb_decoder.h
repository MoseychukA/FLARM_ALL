#pragma once
#include <Arduino.h>
struct CprRef{ double ref_lat; double ref_lon; };
bool cpr_global_decode(double&, double&, const uint8_t*, const uint8_t*);
bool cpr_local_decode(double&, double&, const uint8_t*, const CprRef&);
int decode_altitude(const uint8_t*);
bool decode_velocity_tc19(const uint8_t*, double&, double&, int&, int&);
void decode_callsign(const uint8_t*, char*);

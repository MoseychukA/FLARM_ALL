#include "adsb_decoder.h"
#include <math.h>
bool cpr_global_decode(double&, double&, const uint8_t*, const uint8_t*){return false;}
bool cpr_local_decode(double&, double&, const uint8_t*, const CprRef&){return false;}
int decode_altitude(const uint8_t*){return -1;}
bool decode_velocity_tc19(const uint8_t*, double&, double&, int&, int&){return false;}
void decode_callsign(const uint8_t*, char*){}

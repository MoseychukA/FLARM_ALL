
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <semphr.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/adc.h"
#include "hardware/gpio.h"
#include "adsb_sampler.pio.h"
#include "adsb_crc.h"
#include "adsb_decoder.h"
#include "dma_ring.h"
static const uint32_t SAMPLE_RATE_HZ=10000000u; static const uint8_t T04=(uint8_t)(SAMPLE_RATE_HZ*0.4e-6+0.5), T05=(uint8_t)(SAMPLE_RATE_HZ*0.5e-6+0.5), T07=(uint8_t)(SAMPLE_RATE_HZ*0.7e-6+0.5), TBIT=(uint8_t)(SAMPLE_RATE_HZ*1.0e-6+0.5); static const uint16_t TPRE=(uint16_t)(SAMPLE_RATE_HZ*8.0e-6+0.5);
static float g_neg_avg=0.0f; static float g_neg_alpha=0.02f; static int g_base_thr=36; static float g_k=1.5f; static const int PRE_PENALTY_THR=6; static const int PRE_MIN_POS_HITS=14;
struct PreambleState{ uint32_t shift[4]; bool last; uint8_t runlen; uint32_t sample_pos; uint32_t pulse_times[4096]; uint16_t phead,ptail; };
static bool corr_preamble_and_get_t0(const PreambleState &ps, uint32_t cur_pos, uint32_t &t0){
  uint8_t bits[80]; for(int i=0;i<80;i++){ int idx=127-i; int w=idx>>5; int b=31-(idx&31); bits[79-i]=(ps.shift[w]>>b)&1; }
  int score=0, penalty=0, posHits=0, negHits=0; for(int i=0;i<80;i++){ bool expect=((i>=2 && i<=7)||(i>=12 && i<=17)||(i>=37 && i<=42)||(i>=47 && i<=52)); if(bits[i]){ if(expect){ score+=3; posHits++; } else { score+=-1; negHits++; penalty++; } } }
  int dynamic_thr = g_base_thr + (int)(g_k * g_neg_avg); bool ok = (score >= dynamic_thr) && (penalty <= PRE_PENALTY_THR) && (posHits >= PRE_MIN_POS_HITS); if(!ok){ g_neg_avg = (1.0f - g_neg_alpha)*g_neg_avg + g_neg_alpha*(float)negHits; return false; } t0 = cur_pos - 80; return true; }

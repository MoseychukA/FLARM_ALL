
# ADS-B RP2040 FreeRTOS Receiver — v2.3 (DMA + Adaptive + Gillham + TC19 + BDS60/61 + NVS)

Новое в v2.3:
- Парсер Mode S Comm-B BDS 6,0 / 6,1:
  - BDS 6,0: извлечение барометрической вертикальной скорости (и инерциальной, если есть)
  - BDS 6,1: извлечение разности геометрической и барометрической высоты (baro-geo diff), трека/скорости/поворота (при наличии)
- Постоянные настройки в Flash (LittleFS): сохранение/загрузка профилей/режимов/REF через команды
- Совместимо с v2.2: форматы CSV/UBX/NMEA/JSON/RAW, профили Normal/High-EMI, DMA-кольца, адаптивный коррелятор, Gillham(Q=0), TC=19 (1/2/3/4)

Команды Serial2:
- MODE CSV|NMEA|JSON|UBX|RAW
- PROFILE NORMAL|EMI
- LOG ON|OFF
- REF <lat> <lon>
- SAVE / LOAD / SHOW
- HELP

Требования: Arduino IDE 2.3.2, RP2040 core 3.7.2, FreeRTOS_RP2040 1.3.2, LittleFS (включено в RP2040 core).


#pragma once
#include <Arduino.h>
struct Settings {
  String mode;      // CSV/NMEA/JSON/UBX/RAW
  String profile;   // NORMAL/EMI
  bool log_on;      // true/false
  double ref_lat;   // CPR ref
  double ref_lon;   // CPR ref
};

bool storage_init();
bool storage_save(const Settings& s);
bool storage_load(Settings& s);


# ADS-B RP2040 FreeRTOS Receiver — v2.2 (DMA + Adaptive + Gillham + TC19 + CSV/UBX + NMEA/JSON + Profiles)

Новое в v2.2:
- Логирование и вывод форматов:
  - CSV (строки с полями для последующего анализа)
  - NMEA-предложение $PADSB (кастомное)
  - JSON (одна строка на сообщение)
  - UBX (кастомный двоичный кадр UBX-стиля для ADS-B)
  - RAW (как раньше)
- Профили преамбулы: Normal / High-EMI. Переключение командами по Serial2.
- Команды по Serial2:
  - MODE CSV|NMEA|JSON|UBX|RAW — выбрать формат вывода
  - PROFILE NORMAL|EMI — переключить профиль коррелятора
  - LOG ON|OFF — включить/выключить дублирующий CSV-лог
  - REF <lat> <lon> — задать опорную точку для локального CPR
  - HELP — список команд

Остальное: DMA-кольца на 3 канала, адаптивный коррелятор (EMA), CPR global/local, Gillham (Q=0), TC=19 1/2/3/4, UART2 921600 бод.

Инструменты: Arduino IDE 2.3.2, Earle Philhower RP2040 core 3.7.2, FreeRTOS_RP2040 1.3.2.

// rp2040_adsb_receiver.ino
#include <Arduino.h>
#include <LittleFS.h>
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/dma.h"
#include "hardware/regs/dreq.h"
#include "hardware/sync.h"
#include "hardware/irq.h"
#include "adsb_sampler.pio.h"
#include "protocol.h"
#include "crc.h"
#include "cpr.h"
#include "adsb_decoder.h"
#include "bds.h"
#include "config.h"

static const uint32_t USB_BAUD = 115200;
static const int UART2_TX = 4;
static const int UART2_RX = 5;
static const uint32_t UART2_BAUD = 921600;
static const int CH_PIN[3] = {18,19,22};
static const int PRE_IND_PIN[3] = {17,20,23};
static const int RSSI_PIN = 26;
static const int CORE0_TOGGLE_PIN = 15;
static const int CORE1_TOGGLE_PIN = 25;
static const uint32_t SAMPLE_RATE_HZ = 10000000UL;
static const uint32_t RING_WORDS = 1<<12;
static const uint32_t RING_MASK = RING_WORDS-1;

static volatile uint32_t *ringbuf[3];
static volatile uint32_t write_idx[3];
static volatile uint32_t read_idx[3];

static PIO pio = pio0;
static int sm_idx[3];
static int dma_chan[3];

volatile bool filter_enabled = true;
volatile float filt_min_us = 0.4f;
volatile float filt_max_us = 0.7f;
volatile float normalize_to_us = 0.5f;
volatile float g_base_thr = 0.25f;
volatile float ema_alpha = 0.02f;
volatile float k_dyn = 1.5f;
volatile uint32_t dead_time_us = 7;
volatile Profile current_profile = Profile::Normal;

CPRContext cpr_ctx;

static const size_t OUT_Q_CAP = 256;
FOFrame out_queue[OUT_Q_CAP];
volatile uint16_t out_q_head=0, out_q_tail=0;

static const size_t RAW_Q_CAP = 512;
RawPacket raw_q[3][RAW_Q_CAP];
volatile uint16_t raw_head[3]={0}, raw_tail[3]={0};

volatile float rssi_ema = 0.0f;
volatile float rssi_alpha = 0.05f;
volatile uint32_t core0_last_toggle=0, core1_last_toggle=0;

static inline void pin_fast_out(int gpio){ gpio_init(gpio); gpio_set_dir(gpio, GPIO_OUT); }
static inline void pin_fast_in(int gpio){ gpio_init(gpio); gpio_set_dir(gpio, GPIO_IN); }
static inline void gpio_write(int gpio, bool v){ gpio_put(gpio, v); }
static inline uint32_t micros32(){ return (uint32_t)time_us_32(); }

static inline void raw_enqueue(int ch, const RawPacket &rp){ uint16_t nxt=(raw_head[ch]+1)%RAW_Q_CAP; if (nxt==raw_tail[ch]) return; raw_q[ch][raw_head[ch]]=rp; raw_head[ch]=nxt; }
static inline bool raw_dequeue_any(int &ch, RawPacket &rp){ for(int i=0;i<3;i++){ if (raw_tail[i]!=raw_head[i]){ ch=i; rp=raw_q[i][raw_tail[i]]; raw_tail[i]=(raw_tail[i]+1)%RAW_Q_CAP; return true; } } return false; }
static inline void out_enqueue(const FOFrame &fo){ uint16_t nxt=(out_q_head+1)%OUT_Q_CAP; if (nxt==out_q_tail) return; out_queue[out_q_head]=fo; out_q_head=nxt; }
static inline bool out_dequeue(FOFrame &fo){ if (out_q_tail==out_q_head) return false; fo=out_queue[out_q_tail]; out_q_tail=(out_q_tail+1)%OUT_Q_CAP; return true; }

static void setup_pio_sm(int ch, int pin){ static int prog_offset=-1; if (prog_offset<0) prog_offset=pio_add_program(pio, &adsb_sampler_program); sm_idx[ch]=pio_claim_unused_sm(pio,true); adsb_sampler_program_init(pio, sm_idx[ch], prog_offset, pin, SAMPLE_RATE_HZ); }
static void setup_dma_for_sm(int ch){ dma_chan[ch]=dma_claim_unused_channel(true); dma_channel_config c=dma_channel_get_default_config(dma_chan[ch]); channel_config_set_read_increment(&c,false); channel_config_set_write_increment(&c,true); channel_config_set_dreq(&c, pio_get_dreq(pio, sm_idx[ch], false)); channel_config_set_transfer_data_size(&c, DMA_SIZE_32); channel_config_set_ring(&c,true,12); dma_channel_configure(dma_chan[ch], &c, (void*)ringbuf[ch], &pio->rxf[sm_idx[ch]], RING_WORDS, true); }

struct DetectState{ uint32_t last_detect_us=0; float noise_ema=0.0f; };
static DetectState det[3];

static inline uint8_t get_sample_bit(uint32_t w,int i){ return (w>>i)&1u; }

static int corr_preamble_and_get_t0(const uint8_t *s,int len,int ch){ if(len<80) return -1; const int A=0,B=10,C=35,D=45; int posHitsA=0,posHitsB=0,posHitsC=0,posHitsD=0; int negHits=0; auto window_score=[&](int center){ int hits=0; for(int i=-3;i<=3;i++){ int idx=center+i; if(idx>=0 && idx<len) hits+=s[idx]; } return hits;}; posHitsA=window_score(A); posHitsB=window_score(B); posHitsC=window_score(C); posHitsD=window_score(D); for(int i=0;i<80;i++){ bool inPos=(abs(i-A)<=3)||(abs(i-B)<=3)||(abs(i-C)<=3)||(abs(i-D)<=3); if(!inPos && s[i]) negHits++; }
  int run=0; for(int i=0;i<80;i++){ run=s[i]?run+1:0; if(run>7) return -1; }
  int posScore=posHitsA+posHitsB+posHitsC+posHitsD; float dyn_thr=g_base_thr + k_dyn*det[ch].noise_ema; float score=(posScore - negHits)/28.0f; if(score<dyn_thr){ det[ch].noise_ema=(1.0f-ema_alpha)*det[ch].noise_ema + ema_alpha*(negHits/60.0f); return -1; }
  int tol=(current_profile==Profile::HighEMI)?1:2; int bestA=0,bestAh=posHitsA; for(int i=-2;i<=2;i++){ int c=A+i; if(c>=0){ int h=window_score(c); if(h>bestAh){bestAh=h; bestA=c;} } } int dAB=B-bestA, dBC=C-B, dCD=D-C; if(abs(dAB-10)>tol||abs(dBC-25)>tol||abs(dCD-10)>tol){ det[ch].noise_ema=(1.0f-ema_alpha)*det[ch].noise_ema + ema_alpha*(negHits/60.0f); return -1; }
  return 0;
}

static void digital_filter_samples(uint8_t *s,int n){ if(!filter_enabled) return; int minS=(int)roundf(filt_min_us*SAMPLE_RATE_HZ/1e6f); int maxS=(int)roundf(filt_max_us*SAMPLE_RATE_HZ/1e6f); int normS=(int)roundf(normalize_to_us*SAMPLE_RATE_HZ/1e6f); int i=0; while(i<n){ if(!s[i]){ i++; continue;} int j=i; while(j<n&&s[j]) j++; int w=j-i; if(w<minS||w>maxS){ for(int k=i;k<j;k++) s[k]=0; } else { for(int k=i;k<j;k++) s[k]=(k<i+normS)?1:0; } i=j; } }

static int extract_packet_bits(const uint8_t *s,int len,uint8_t *outB,int maxBytes){ const int bitSamp=10, preSamp=80; auto try_extract=[&](int nBits){ int nBytes=(nBits+7)/8; if(nBytes>maxBytes) return false; memset(outB,0,nBytes); for(int b=0;b<nBits;b++){ int center=preSamp+b*bitSamp+bitSamp/2; if(center+2>=len) return false; int early=0,late=0; for(int k=-2;k<=2;k++){ int idx=center+k; if(idx>=preSamp && idx<len){ if(k<=0) early+=s[idx]; else late+=s[idx]; } } int bit=(early>late)?1:0; outB[b>>3] |= (bit << (7-(b&7))); } return true; };
  if(try_extract(112)) return 112; if(try_extract(56)) return 56; return 0; }

static bool try_single_bit_fix(uint8_t *frame,int nBits){ int nBytes=(nBits+7)/8; for(int i=0;i<nBits;i++){ int by=i>>3, bi=7-(i&7); frame[by]^=(1<<bi); if(modes_crc_ok(frame,nBits)) return true; frame[by]^=(1<<bi);} return false; }

static inline uint32_t dma_write_index_words(int ch){ uint32_t waddr=dma_hw->ch[dma_chan[ch]].write_addr; uint32_t base=(uint32_t)(uintptr_t)ringbuf[ch]; uint32_t off=(waddr-base)>>2; return off & RING_MASK; }

static void channel_process_once(int ch){ static uint8_t win[3][1600]; static int wp_[3]={0,0,0}; int &wp=wp_[ch]; uint32_t widx=dma_write_index_words(ch); while(read_idx[ch]!=widx){ uint32_t w=ringbuf[ch][read_idx[ch]&RING_MASK]; read_idx[ch]++; for(int i=0;i<32;i++){ win[ch][wp]=(w>>i)&1u; wp++; if(wp>=80+112*10+20){ digital_filter_samples(win[ch], wp); int t0=corr_preamble_and_get_t0(win[ch], wp, ch); if(t0>=0){ uint32_t nowus=micros32(); if(nowus - det[ch].last_detect_us >= dead_time_us){ gpio_write(PRE_IND_PIN[ch],1); uint8_t frame[32]={0}; int nBits=extract_packet_bits(win[ch]+t0, wp-t0, frame, sizeof(frame)); gpio_write(PRE_IND_PIN[ch],0); if(nBits==56||nBits==112){ Serial.print(F("RAW CH")); Serial.print(ch+1); Serial.print(F(" ")); for(int i=0;i<(nBits+7)/8;i++){ if(i) Serial.print(' '); Serial.print(frame[i], HEX);} Serial.println(); bool ok=modes_crc_ok(frame,nBits); if(!ok){ uint8_t tmp[32]; memcpy(tmp, frame, sizeof(tmp)); if(try_single_bit_fix(tmp,nBits)){ RawPacket rp; rp.channel=ch; rp.bitlen=nBits; rp.ok=true; memcpy(rp.bytes,tmp,(nBits+7)/8); raw_enqueue(ch,rp);} } else { RawPacket rp; rp.channel=ch; rp.bitlen=nBits; rp.ok=true; memcpy(rp.bytes,frame,(nBits+7)/8); raw_enqueue(ch,rp);} det[ch].last_detect_us=nowus; } } int keep=200; memmove(win[ch], win[ch]+wp-keep, keep); wp=keep; } } } }

void setup1(){ pin_fast_out(CORE1_TOGGLE_PIN); for(int i=0;i<3;i++) pin_fast_out(PRE_IND_PIN[i]); for(int i=0;i<3;i++){ void *buf=malloc(RING_WORDS*sizeof(uint32_t)); ringbuf[i]=(volatile uint32_t*)buf; write_idx[i]=read_idx[i]=0; } for(int i=0;i<3;i++){ setup_pio_sm(i, CH_PIN[i]); setup_dma_for_sm(i);} }

void loop1(){ uint32_t now=millis(); if(now-core1_last_toggle>=500){ core1_last_toggle=now; static bool lv=false; lv=!lv; gpio_write(CORE1_TOGGLE_PIN, lv);} channel_process_once(0); channel_process_once(1); channel_process_once(2); }

static void send_to_esp32(const FOFrame &fo){ PackedFO pkt; packFO(fo,pkt); uint32_t crc=crc32_ieee((const uint8_t*)&pkt, sizeof(pkt)); Serial2.write((const uint8_t*)&pkt, sizeof(pkt)); Serial2.write((const uint8_t*)&crc, 4); }

static void process_packets(){ int ch; RawPacket rp; while(raw_dequeue_any(ch,rp)){ DecodedADSB d{}; if(!adsb_decode(rp.bytes, rp.bitlen, micros32(), cpr_ctx, d)) continue; Serial.print(F("DECODE CH")); Serial.print(ch+1); Serial.print(F(" icao=")); Serial.print(d.addr, HEX); Serial.print(F(" flight="")); Serial.print(d.flight); Serial.print(F("" lat=")); Serial.print(d.lat,6); Serial.print(F(" lon=")); Serial.print(d.lon,6); Serial.print(F(" spd=")); Serial.print(d.speed_kmh); Serial.print(F(" alt=")); Serial.println(d.altitude_m); FOFrame fo{}; fo.addr=d.addr; fo.Squawk=d.squawk; memcpy(fo.flight, d.flight, sizeof(fo.flight)); fo.altitude=d.geo_alt_m; fo.pressure_altitude=d.altitude_m; fo.speed=d.speed_kmh; fo.course=d.track_deg; fo.vert_rate=d.vert_rate_fpm; fo.latitude=d.lat; fo.longitude=d.lon; fo.seen=d.seen_time_ms; fo.timestamp=d.timestamp; fo.signal_source=1; fo.aircraft_type=9; out_enqueue(fo);} }

static void flush_out_queue(){ FOFrame fo; while(out_dequeue(fo)) send_to_esp32(fo); }

static void read_rssi(){ uint16_t v=analogRead(RSSI_PIN); float f=(float)v/4095.0f; rssi_ema=(1.0f-rssi_alpha)*rssi_ema + rssi_alpha*f; }

static void cli_handle_line(const String &line){ if(line.equalsIgnoreCase("SHOW")){ Config cfg=get_config(); Serial.println(cfg.toString()); } else if(line.startsWith("PROFILE")){ String p=line.substring(7); p.trim(); if(p.equalsIgnoreCase("Normal")) set_profile(Profile::Normal); else if(p.equalsIgnoreCase("High-EMI")) set_profile(Profile::HighEMI); else if(p.equalsIgnoreCase("Urban")) set_profile(Profile::Urban); else if(p.equalsIgnoreCase("Remote")) set_profile(Profile::Remote); Serial.println(F("OK")); } else if(line.equalsIgnoreCase("FILTER ON")){ filter_enabled=true; Serial.println(F("OK")); } else if(line.equalsIgnoreCase("FILTER OFF")){ filter_enabled=false; Serial.println(F("OK")); } else if(line.equalsIgnoreCase("SAVE")){ save_config(); Serial.println(F("SAVED")); } else if(line.equalsIgnoreCase("LOAD")){ load_config(); Serial.println(F("LOADED")); } else { Serial.println(F("Unknown command")); } }

void setup(){ Serial.begin(USB_BAUD); while(!Serial && millis()<2000){} Serial2.setTX(UART2_TX); Serial2.setRX(UART2_RX); Serial2.begin(UART2_BAUD); pin_fast_out(CORE0_TOGGLE_PIN); pin_fast_in(RSSI_PIN); analogReadResolution(12); LittleFS.begin(); load_config(); cpr_ctx.init(55.7558, 37.6176); Serial.println(F("RP2040 ADS-B RX start")); }

void loop(){ if(millis()-core0_last_toggle>=1000){ core0_last_toggle=millis(); static bool lv=false; lv=!lv; gpio_write(CORE0_TOGGLE_PIN, lv);} static String l; while(Serial.available()){ char c=(char)Serial.read(); if(c=='
'||c==''){ if(l.length()>0){ cli_handle_line(l); l=""; } } else l+=c; } read_rssi(); process_packets(); flush_out_queue(); }

#include "bds.h"
BDS60 parse_bds60(const uint8_t *me){ BDS60 o; o.valid=false; return o; }
BDS61 parse_bds61(const uint8_t *me){ BDS61 o; o.valid=false; return o; }

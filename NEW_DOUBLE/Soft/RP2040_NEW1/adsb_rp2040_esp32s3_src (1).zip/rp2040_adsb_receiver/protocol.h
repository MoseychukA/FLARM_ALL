#pragma once
#include <Arduino.h>
struct FOFrame { uint32_t addr; uint16_t Squawk; char flight[9]; int32_t altitude; int32_t pressure_altitude; uint16_t speed; uint16_t course; int16_t vert_rate; double latitude; double longitude; uint32_t seen; uint32_t timestamp; uint8_t signal_source; uint8_t aircraft_type; };
#pragma pack(push,1)
struct PackedFO { uint32_t magic; uint32_t addr; uint16_t Squawk; char flight[9]; int32_t altitude; int32_t pressure_altitude; uint16_t speed; uint16_t course; int16_t vert_rate; int32_t lat_mdeg; int32_t lon_mdeg; uint32_t seen; uint32_t timestamp; uint8_t signal_source; uint8_t aircraft_type; };
#pragma pack(pop)
static inline void packFO(const FOFrame &in, PackedFO &out){ out.magic=0x3141764Fu; out.addr=in.addr; out.Squawk=in.Squawk; memcpy(out.flight,in.flight,sizeof(out.flight)); out.altitude=in.altitude; out.pressure_altitude=in.pressure_altitude; out.speed=in.speed; out.course=in.course; out.vert_rate=in.vert_rate; out.lat_mdeg=(int32_t)round(in.latitude*1e6); out.lon_mdeg=(int32_t)round(in.longitude*1e6); out.seen=in.seen; out.timestamp=in.timestamp; out.signal_source=in.signal_source; out.aircraft_type=in.aircraft_type; }
struct RawPacket { uint8_t bytes[32]; uint16_t bitlen; uint8_t channel; bool ok; };
